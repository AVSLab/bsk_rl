"""Real Walker observations; catalog/ideal-link fixtures are labeled explicitly."""
import argparse
from dataclasses import replace
import json
from pathlib import Path
import numpy as np
import torch
from ray.rllib.core.columns import Columns
from bsk_rl import NO_ACTION
from bsk_rl.data.completion_catalog import CompletionRecord
from examples.multiagent_imaging.config import MultiAgentImagingConfig
from examples.multiagent_imaging.environment import build_environment
from examples.multiagent_imaging.checkpoints import load_policy


def main(checkpoint, output):
    torch.set_num_threads(1)
    cfg = MultiAgentImagingConfig(**json.loads((checkpoint/'manifest.json').read_text())['config'])
    module, restore = load_policy(checkpoint, cfg)
    rows, arrays = [], {}

    def capture(env, case):
        env.generate_obs_retasking_only = False
        for s in env.sensing_satellites:
            s.completion_candidates = s.completion_peers = None
            s.observation_builder.obs_dict_cache = None
        obs = env._get_obs()
        a = np.asarray([obs[s.name] for s in env.sensing_satellites], np.float32)
        assert a.shape == (4,232) and np.isfinite(a).all()
        arrays[case] = a
        with torch.no_grad():
            batch = {Columns.OBS: torch.tensor(a)}
            l = module.forward_inference(batch)[Columns.ACTION_DIST_INPUTS]
            for method in [module.forward_train, module.forward_exploration]:
                torch.testing.assert_close(l, method(batch)[Columns.ACTION_DIST_INPUTS], atol=0,rtol=0)
            p = l.softmax(-1)
            g = torch.Generator().manual_seed(2701)
            samples = torch.stack([torch.bincount(torch.multinomial(q,4096,True,generator=g),minlength=18) for q in p])
        for i,s in enumerate(env.sensing_satellites):
            rows.append(dict(case=case,sensor=s.name,time_s=env.simulator.sim_time,
                observation=a[i].tolist(),storage=float(s.dynamics.storage_level_fraction),
                owned_product_count=len(s.data_store.products),
                qualified_owned_product_count=sum(p.quality>=.5 for p in s.data_store.products),
                battery=float(s.dynamics.battery_charge_fraction),task=None if s.completion_task is None else vars(s.completion_task).copy(),
                target_ids=[None if t is None else t.id for t in s.completion_candidates.targets],
                peer_ids=[None if peer is None else peer.name for peer in s.completion_peers.peers],
                valid=(l[i]>-1e8).tolist(),logits=l[i].tolist(),probabilities=p[i].tolist(),categorical_counts=samples[i].tolist()))
        return a,l

    env = build_environment(cfg)
    try:
        env.reset(seed=7001)
        a,l = capture(env,'real_empty_reset')
        assert (l[:,1]<-1e8).all() and (l[:,5:15]>-1e8).all()
        # Run actual imaging until physical products exist. Forced NO_ACTION is plumbing.
        for _ in range(80):
            env.step({s.name:5 if s.requires_retasking else NO_ACTION for s in env.sensing_satellites})
            if any(any(p.quality>=.5 for p in s.data_store.products) for s in env.sensing_satellites):
                break
        a,l=capture(env,'real_products_and_task')
        filled=a[:,0]>cfg.empty_storage_mask_fraction
        assert filled.any() and (l[filled,1]>-1e8).all()
        assert any(any(p.quality>=.5 for p in s.data_store.products) for s in env.sensing_satellites)
        continuing=a[:,25]>.5
        assert continuing.any() and (l[continuing,4]>-1e8).all()
    finally:
        env.close()
    env=build_environment(cfg)
    for s in env.sensing_satellites:
        s.sat_args_generator['storedCharge_Init']=.04*s.sat_args_generator['batteryStorageCapacity']
    try:
        env.reset(seed=7001)
        a,l=capture(env,'real_low_battery_reset')
        assert np.allclose(a[:,1],.04) and (l[:,0]>-1e8).all()
        assert (l[:,[1,2,3,*range(5,18)]]<-1e8).all()
        try:
            env.step({s.name:5 for s in env.sensing_satellites})
        except ValueError as e:
            rejection=str(e)
        else:
            raise AssertionError('Low-battery image was not rejected')
        env.max_step_duration=5
        env.simulator.max_step_duration=5
        env.step({s.name:0 for s in env.sensing_satellites})
        a,l=capture(env,'real_low_battery_active_charge')
        assert (a[:,25]>.5).all() and (a[:,1]<cfg.minimum_task_battery_fraction).all()
        assert (l[:,[0,4]]>-1e8).all() and (l[:,[1,2,3,*range(5,18)]]<-1e8).all()
    finally:
        env.close()
    # Physical Walker positions + real observation builder, injected completion
    # record and ideal-link fixture: this checks encoding, not natural LOS incidence.
    env=build_environment(replace(cfg,link_mode='ideal'))
    try:
        env.reset(seed=7001)
        sender,*peers=env.sensing_satellites
        tid=next(iter(sender.data_store.catalog.targets))
        record=CompletionRecord('audit_fixture',sender.name,tid,0,0,0,True)
        sender.data_store.catalog.merge_record(record,0)
        for slot in range(3):
            env.communicator.acknowledged={(sender.name,p.name):({} if j==slot else {record.record_id:record.version}) for j,p in enumerate(peers)}
            a,l=capture(env,f'catalog_ideal_link_peer_{slot}')
            assert [p is not None for p in sender.completion_peers.peers]==[j==slot for j in range(3)]
            assert (l[0,15:]>-1e8).tolist()==[j==slot for j in range(3)]
    finally:
        env.close()
    with output.open('x') as f:
        json.dump(dict(config=cfg.to_dict(),restore=restore,rows=rows,low_battery_rejection=rejection,
            caveat='Current local Basilisk, 1200 s; injected catalog and ideal link are controlled fixtures, not mission coverage.'),f,indent=2,allow_nan=False)
    np.savez_compressed(output.with_suffix('.npz'),**arrays)
    print(json.dumps(dict(passed=True,cases=list(arrays),rows=len(rows))))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();main(a.checkpoint,a.output)
