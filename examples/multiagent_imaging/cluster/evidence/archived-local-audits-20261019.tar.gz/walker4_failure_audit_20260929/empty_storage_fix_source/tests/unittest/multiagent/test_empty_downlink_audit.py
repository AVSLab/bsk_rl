"""Regression for the proven v3 empty-downlink defect; no simulator needed.

Run this file with the archived v3 PYTHONPATH for the expected failure, or current
v4 PYTHONPATH for the pass. It uses each source's own schema, never mixed weights.
"""
import gymnasium as gym
import numpy as np
import torch
from ray.rllib.algorithms.ppo.ppo_catalog import PPOCatalog
from ray.rllib.core.columns import Columns
from ray.rllib.core.rl_module.rl_module import RLModuleSpec
from bsk_rl.utils.rllib.target_gnn_module import GNNModule
from examples.multiagent_imaging.config import MultiAgentImagingConfig
from examples.multiagent_imaging.train import target_attention_config


def test_no_empty_downlink_and_product_downlink_remains_available():
    torch.set_num_threads(1)
    cfg=MultiAgentImagingConfig(n_sensors=4,n_targets=100,n_candidates=10,
        information_case='completion',communication_mode='directed')
    m=RLModuleSpec(module_class=GNNModule,catalog_class=PPOCatalog,
        observation_space=gym.spaces.Box(-np.inf,np.inf,(232,),np.float32),
        action_space=gym.spaces.Discrete(18),model_config_dict=target_attention_config(cfg)).build()
    x=torch.zeros(2,232);x[:,1]=.9;x[1,0]=.1
    x[:,26:196].reshape(2,10,17)[:,:,-1]=1
    for method in [m.forward_train,m.forward_inference,m.forward_exploration]:
        l=method({Columns.OBS:x})[Columns.ACTION_DIST_INPUTS]
        assert l[0,1]<-1e8,'Empty-storage downlink remained valid'
        assert l[1,1]>-1e8,'Product-present downlink was masked'
        assert (l[:,5:15]>-1e8).all()


if __name__=='__main__':
    test_no_empty_downlink_and_product_downlink_remains_available()
    print('PASS: empty storage blocks downlink; products and ten image slots remain valid')
