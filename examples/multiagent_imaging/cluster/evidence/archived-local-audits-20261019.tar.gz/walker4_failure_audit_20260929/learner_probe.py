"""Diagnostic instrumentation only; identical PPO objective and hyperparameters.

Run with python -c 'from ...learner_probe import run; run(...)' so the learner
class has a stable import path. At most one update, zero remote env runners.
"""
import json
import os
from pathlib import Path

import numpy as np
import torch
from ray.rllib.core.columns import Columns
from ray.rllib.evaluation.postprocessing import Postprocessing
from bsk_rl.utils.rllib.discounting import TimeDiscountedGAEPPOTorchLearner


class DiagnosticLearner(TimeDiscountedGAEPPOTorchLearner):
    def compute_loss_for_module(self, *, module_id, config, batch, fwd_out):
        loss = super().compute_loss_for_module(module_id=module_id, config=config, batch=batch, fwd_out=fwd_out)
        module = self.module[module_id].unwrapped()
        cls = module.get_train_action_dist_cls()
        dist = cls.from_logits(fwd_out[Columns.ACTION_DIST_INPUTS])
        ratio = torch.exp(dist.logp(batch[Columns.ACTIONS]) - batch[Columns.ACTION_LOGP])
        adv = batch[Postprocessing.ADVANTAGES]
        vt = batch[Postprocessing.VALUE_TARGETS]
        vf = fwd_out[Columns.VF_PREDS]
        valid_rows = batch.get(Columns.LOSS_MASK, torch.ones_like(adv, dtype=torch.bool)).bool()
        mean = lambda x: x[valid_rows].mean()
        pl = -mean(torch.minimum(adv * ratio, adv * ratio.clamp(1-config.clip_param, 1+config.clip_param)))
        vl = mean((vf-vt).square().clamp(0, config.vf_clip_param))
        ent = -self.entropy_coeff_schedulers_per_module[module_id].get_current_value() * mean(dist.entropy())
        params = list(module.named_parameters())
        contributions = {}
        for label, term in [("policy", pl), ("value", vl), ("entropy", ent), ("total", loss)]:
            grads = torch.autograd.grad(term, [p for _, p in params], allow_unused=True, retain_graph=True)
            groups = {}
            for (name, _), g in zip(params, grads):
                if g is None:
                    continue
                group = "critic" if name.startswith("vf") else "operational_head" if ".no_action_head." in name else "peer_head" if name.startswith("pi_head.score") else "image_head" if ".out_layer_g." in name else "actor_body"
                groups[group] = groups.get(group, 0) + float(g.detach().square().sum())
            contributions[label] = {k: v**0.5 for k, v in groups.items()}
        idx = getattr(self, "audit_batch_index", 0) + 1
        self.audit_batch_index = idx
        out = Path(os.environ["WALKER_AUDIT_LEARNER_OUTPUT"])
        out.mkdir(parents=True, exist_ok=True)
        arrays = dict(observations=batch[Columns.OBS], actions=batch[Columns.ACTIONS],
            standardized_advantages=adv, value_targets=vt, values=vf,
            old_logits=batch[Columns.ACTION_DIST_INPUTS], new_logits=fwd_out[Columns.ACTION_DIST_INPUTS],
            ratio=ratio, loss_mask=valid_rows)
        arrays = {k: v.detach().cpu().numpy() for k, v in arrays.items()}
        np.savez_compressed(out / f"minibatch_{idx:04d}.npz", **arrays)
        logits = fwd_out[Columns.ACTION_DIST_INPUTS].detach()[valid_rows]
        valid = logits > -1e8
        probs = torch.softmax(logits, -1)
        counts = valid.sum(-1)
        h = -(probs * probs.clamp_min(1e-30).log()).sum(-1)
        stats = {}
        for name in ["standardized_advantages", "value_targets", "values", "observations"]:
            a = arrays[name][arrays['loss_mask']]
            stats[name] = dict(min=float(a.min()), max=float(a.max()), mean=float(a.mean()), std=float(a.std()), finite=bool(np.isfinite(a).all()))
        record = dict(batch_index=idx, valid_samples=int(valid_rows.sum()),
            clipping_fraction=float(mean(((ratio - 1).abs() > config.clip_param).float())),
            value_clamp_fraction=float(mean(((vf-vt).square() > config.vf_clip_param).float())),
            vf_clip_param=config.vf_clip_param,
            normalized_entropy=float(torch.where(counts > 1, h / counts.float().log().clamp_min(1e-9), torch.ones_like(h)).mean()),
            valid_action_counts=counts.cpu().tolist(), gradient_contributions=contributions,
            distributions=stats,
            action_count=torch.bincount(batch[Columns.ACTIONS][valid_rows].long(), minlength=18).cpu().tolist(),
            advantage_by_action={str(i): dict(count=int((batch[Columns.ACTIONS][valid_rows]==i).sum()),
                mean=float(adv[valid_rows][batch[Columns.ACTIONS][valid_rows]==i].mean()))
                for i in range(18) if (batch[Columns.ACTIONS][valid_rows]==i).any()})
        with (out / f"minibatch_{idx:04d}.json").open('x') as f:
            json.dump(record, f, indent=2, allow_nan=False)
        return loss


def run(config_path, output):
    from examples.multiagent_imaging import train
    from examples.multiagent_imaging.config import MultiAgentImagingConfig
    output = Path(output)
    if output.exists():
        raise FileExistsError(output)
    os.environ['WALKER_AUDIT_LEARNER_OUTPUT'] = str(output / 'learner_batches')
    cfg = MultiAgentImagingConfig(**json.loads(Path(config_path).read_text()))
    assert cfg.episode_duration_s <= 1200 and cfg.n_sensors == 4 and cfg.n_candidates == 10 and cfg.n_targets == 100
    original = train.build_ppo_config

    def diagnostic_config(*args, **kwargs):
        c = original(*args, **kwargs)
        return c.training(learner_class=DiagnosticLearner)

    train.build_ppo_config = diagnostic_config
    train.train_run(cfg, iterations=1, train_batch_size=64, output=output,
        resources=train.LauncherResources(num_env_runners=0, ray_cpus=2, torch_threads=1))
