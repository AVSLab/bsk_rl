"""Controlled single-feature contrasts on frozen real observations; no rollout."""
import json
from pathlib import Path
import numpy as np,torch
from ray.rllib.core.columns import Columns
from examples.multiagent_imaging.config import MultiAgentImagingConfig
from examples.multiagent_imaging.checkpoints import load_policy

here=Path(__file__).resolve().parent;torch.set_num_threads(1)
checkpoint=here/'local_update_v2/checkpoint_0001'
cfg=MultiAgentImagingConfig(**json.loads((checkpoint/'manifest.json').read_text())['config'])
m,restore=load_policy(checkpoint,cfg)
base=np.load(here/'local_update_post_probe.npz')['real_reset'][:1].copy()
contrasts=[('battery_healthy',1,-.1),('sun_direction',5,.05),('target0_priority',26,.1),('target0_relative_position',27,.1),('task_image_indicator',18,1.0)]
peer=next(r for r in json.loads((here/'physical_probe_v3.json').read_text())['rows'] if r['case']=='catalog_ideal_link_peer_0' and r['sensor']=='sensor_0')
rows=[]
for name,index,delta in contrasts+[('peer0_relative_beacon',196,.1)]:
    x=np.asarray([peer['observation']],np.float32) if name.startswith('peer') else base.copy()
    y=x.copy();y[:,index]+=delta
    with torch.no_grad():
        a=m.forward_inference({Columns.OBS:torch.tensor(x)})[Columns.ACTION_DIST_INPUTS][0]
        b=m.forward_inference({Columns.OBS:torch.tensor(y)})[Columns.ACTION_DIST_INPUTS][0]
        common=(a>-1e8)&(b>-1e8)
        rows.append(dict(contrast=name,feature_index=index,feature_delta=delta,
            common_valid_logit_max_difference=float((b[common]-a[common]).abs().max()),
            logits_before=a.tolist(),logits_after=b.tolist(),mask_equal=bool(torch.equal(a>-1e8,b>-1e8)),
            probability_max_difference=float((b.softmax(-1)-a.softmax(-1)).abs().max())))
with (here/'paired_sensitivity.json').open('x') as f:json.dump(dict(restore=restore,contrasts=rows,
    caveat='Tensor changes to real observations; sensitivity checks encoding, not learned causal relevance. Peer baseline uses injected catalog/ideal link.'),f,indent=2)
print(json.dumps([{k:r[k] for k in ['contrast','common_valid_logit_max_difference','mask_equal']} for r in rows]))
