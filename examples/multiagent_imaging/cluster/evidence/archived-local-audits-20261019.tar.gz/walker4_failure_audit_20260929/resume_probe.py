"""Restore a local zero-runner checkpoint without taking any training step."""
import argparse,json
from pathlib import Path
import torch,ray
from examples.multiagent_imaging.config import MultiAgentImagingConfig
from examples.multiagent_imaging.checkpoints import resume_checkpoint,optimizer_digest
from examples.multiagent_imaging.train import LauncherResources

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert not a.output.exists()
    m=json.loads((a.checkpoint/'manifest.json').read_text())
    cfg=MultiAgentImagingConfig(**m['config'])
    assert cfg.episode_duration_s<=1200
    torch.set_num_threads(1); ray.init(num_cpus=2,include_dashboard=False)
    algo=None
    try:
        algo=resume_checkpoint(a.checkpoint,cfg,resources=LauncherResources(num_env_runners=0,ray_cpus=2,torch_threads=1))
        result=dict(passed=True,training_iteration=algo.training_iteration,optimizer_digest=optimizer_digest(algo),
            expected_optimizer_digest=m['optimizer_sha256'],num_env_runners=algo.config.num_env_runners,
            note='Restored weights, Adam moments/counters and seed stream at complete-episode boundary; no train() call.')
        with a.output.open('x') as f:json.dump(result,f,indent=2)
        print(json.dumps(result))
    finally:
        if algo:algo.stop()
        ray.shutdown()
