"""Verify original inputs and index this audit package without modifying evidence."""
import hashlib,json,subprocess
from pathlib import Path

here=Path(__file__).resolve().parent
root=Path(json.loads((here/'provenance_before.json').read_text())['root'])
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
before=json.loads((here/'input_hashes_before.json').read_text())
provenance=json.loads((here/'provenance_before.json').read_text())


def changes(mapping):
    missing=[];changed=[]
    for rel,old in mapping.items():
        path=root/rel
        if not path.is_file():missing.append(rel)
        elif sha(path)!=old:changed.append(dict(path=rel,starting_sha256=old,current_sha256=sha(path)))
    return missing,changed


historical_missing,historical_changed=changes(before)
source_missing,source_changed=changes(provenance['source_sha256'])
tracked_patch_matches=(subprocess.check_output(['git','diff','--binary'],cwd=root)
    ==(here/'source_before.patch').read_bytes())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
expected_head=provenance['git']['commit'].strip()
protected_source=[p for p in provenance['source_sha256'] if
    p.startswith('src/bsk_rl/') or p in {
        'examples/multiagent_imaging/config.py',
        'examples/multiagent_imaging/train.py',
        'examples/multiagent_imaging/environment.py',
        'examples/multiagent_imaging/checkpoints.py',
        'examples/multiagent_imaging/evaluate.py',
        'examples/multiagent_imaging/training_audit.py'}]
protected_changed=[c for c in source_changed if c['path'] in protected_source]
check=dict(historical_inputs_count=len(before),historical_missing=historical_missing,
    historical_changed=historical_changed,historical_preserved=not historical_missing and not historical_changed,
    fingerprinted_source_count=len(provenance['source_sha256']),source_missing=source_missing,
    source_changed=source_changed,protected_experiment_source_count=len(protected_source),
    protected_experiment_source_unchanged=not protected_changed and not any(p in source_missing for p in protected_source),
    tracked_preexisting_patch_matches=tracked_patch_matches,git_head=head,git_head_matches_start=head==expected_head,
    note='Unrelated source drift is recorded, not overwritten. Historical results and tracked pre-existing changes remain untouched.')
assert check['historical_preserved'] and check['protected_experiment_source_unchanged']
assert tracked_patch_matches and check['git_head_matches_start']
with (here/'preservation_check.json').open('x') as f:json.dump(check,f,indent=2);f.write('\n')

excluded={'artifact_manifest.json','__pycache__'}
files=[]
for path in sorted(here.rglob('*')):
    if (not path.is_file() or any(part in excluded for part in path.relative_to(here).parts)
            or path.suffix=='.pyc'):
        continue
    files.append(dict(path=str(path.relative_to(here)),bytes=path.stat().st_size,sha256=sha(path)))
manifest=dict(root=str(here),git_head=head,files=files,file_count=len(files),
    total_bytes=sum(x['bytes'] for x in files),
    excluded='artifact_manifest.json, __pycache__ and .pyc; hash with SHA-256',
    status='Evidence package prepared; one-worker 45000-second gate unexecuted')
with (here/'artifact_manifest.json').open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
print(json.dumps(dict(historical_preserved=check['historical_preserved'],
    source_drift=len(source_changed),protected_experiment_source_unchanged=check['protected_experiment_source_unchanged'],
    tracked_preexisting_patch_matches=tracked_patch_matches,indexed_files=len(files),indexed_bytes=manifest['total_bytes'])))
