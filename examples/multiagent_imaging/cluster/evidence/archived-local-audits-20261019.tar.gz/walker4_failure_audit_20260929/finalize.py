"""Build a fresh final analysis from retained inputs and labeled transcriptions."""
import argparse,csv,hashlib,json,math
from collections import Counter
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from analyze import write_csv,distribution_rows,extract_events,plot_resources

here=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=here/'analysis_v2');args=p.parse_args()
out=args.output;out.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text())
readcsv=lambda p:list(csv.DictReader(p.open()))
updates=readcsv(here/'retained_analysis_v2/updates_diagnostic.csv')
cluster=readcsv(here/'cluster_checkpoint_transcription.csv')
events=readcsv(here/'cluster_event_transcription.csv')
for row in updates:
    if row['version']!='v3':continue
    match=next(c for c in cluster if c['stage']==row['stage'] and c['mode']==row['mode'] and float(c['iteration'])==float(row['iteration']))
    row.update({'terminal_probe_'+k:v for k,v in match.items() if k not in ['stage','mode','iteration']})
    row['terminal_probe_source']='Live Termius manually transcribed stdout, six decimals; new terminal observations at each update'
    if row['stage']=='four_worker_pilot':
        e=next(e for e in events if e['mode']==row['mode'] and float(e['iteration'])==float(row['iteration']))
        row.update({k:v for k,v in e.items() if k not in ['mode','iteration']})
    row['optimizer_digest']=''
    if row['stage']=='four_worker_pilot' and float(row['iteration'])==8:
        m=load(here.parent/'walker4_completion_v3_cluster_pilot/checkpoint_manifests'/f"{row['mode']}_manifest.json")
        row['optimizer_digest']=m['optimizer_sha256']

folder=here/'local_update_v2';r=load(folder/'updates.json')[0];lm=r['learner_metrics'];es=r['episodes']
rh=[h for e in es for h in e['resource_history']]
row=dict(version='v4',stage='fresh_local_audit',mode='conflict',selection='training_categorical',horizon_s=1200,
    iteration=1,complete_episodes=len(es),actual_env_steps=r['actual_env_steps'],actual_agent_steps=r['actual_agent_steps'],
    actual_policy_decisions=r['actual_policy_decisions'],mean_constellation_reward=np.mean([e['constellation_reward'] for e in es]),
    policy_loss=lm['policy_loss'],total_loss=lm['total_loss'],value_loss=lm['vf_loss'],value_loss_unclipped=lm['vf_loss_unclipped'],
    entropy=lm['entropy'],entropy_coefficient=lm['curr_entropy_coeff'],kl=lm['mean_kl_loss'],explained_variance=lm['vf_explained_var'],
    gradient_l2=r['gradient_l2'],parameter_change_l2=r['parameter_change']['l2'],learner_samples=lm['num_module_steps_trained'],
    minimum_battery_fraction=min(h['battery_fraction'] for h in rh),maximum_storage_fraction=max(h['storage_fraction'] for h in rh),
    accepted_packets=sum(p['outcome']=='accepted' for e in es for p in e['packets']),
    optimizer_digest=load(folder/'checkpoint_0001/manifest.json')['optimizer_sha256'],source=str(folder/'updates.json'))
for col,key in [('acquisition','acquisition_90_percent_component'),('ground','ground_delivery_10_percent_component'),
    ('communication_adjustment','communication_time_adjustment'),('other_penalties_or_adjustments','other_operational_penalties_or_adjustments')]:
    row['mean_'+col+('_reward' if col in ['acquisition','ground'] else '')]=np.mean([e['reward_decomposition'][key] for e in es])
updates.append(row)

minibatches=[];grads=[];arrays=[];seen=set();unique=[]
for f in sorted((folder/'learner_batches').glob('*.json')):
    d=load(f);a=np.load(f.with_suffix('.npz'));arrays.append(a)
    minibatches.append({k:v for k,v in d.items() if k not in ['gradient_contributions','distributions','advantage_by_action','valid_action_counts','action_count']})
    for term,gs in d['gradient_contributions'].items():
        for group,norm in gs.items():grads.append(dict(minibatch=d['batch_index'],term=term,group=group,unclipped_gradient_l2=norm))
    for o,act,adv,vt,v,l,n,ratio in zip(a['observations'],a['actions'],a['standardized_advantages'],a['value_targets'],a['values'],a['old_logits'],a['new_logits'],a['ratio']):
        digest=hashlib.sha256(o.tobytes()+np.asarray(act).tobytes()+np.asarray(adv).tobytes()).hexdigest()
        if digest not in seen:
            seen.add(digest);unique.append(dict(obs=o,action=int(act),adv=float(adv),target=float(vt),value=float(v),old_logits=l,new_logits=n,ratio=float(ratio)))
assert len(unique)==r['actual_policy_decisions']==86
row['minibatch_presentations']=sum(d['valid_samples'] for d in minibatches)
row['clipping_fraction']=np.mean([d['clipping_fraction'] for d in minibatches])
row['value_clamp_fraction_presentations']=np.mean([d['value_clamp_fraction'] for d in minibatches])
obs=np.stack([u['obs'] for u in unique]);adv=np.array([u['adv'] for u in unique]);acts=np.array([u['action'] for u in unique])
write_csv(out/'updates_diagnostic.csv',updates)
write_csv(out/'learner_minibatches.csv',minibatches);write_csv(out/'gradient_contributions.csv',grads)
from bsk_rl.obs.completion_observations import GLOBAL_FEATURE_ORDER,TARGET_FEATURE_ORDER,PEER_FEATURE_ORDER
names=[*GLOBAL_FEATURE_ORDER,*[f'target_{i}.{f}' for i in range(10) for f in TARGET_FEATURE_ORDER],*[f'peer_{i}.{f}' for i in range(3) for f in PEER_FEATURE_ORDER]]
write_csv(out/'learner_observation_features.csv',[dict(index=i,feature=name,minimum=obs[:,i].min(),maximum=obs[:,i].max(),mean=obs[:,i].mean(),std=obs[:,i].std(),finite=bool(np.isfinite(obs[:,i]).all())) for i,name in enumerate(names)])
labels=['charge','downlink','desat','broadcast','continue',*[f'image_{i}' for i in range(10)],*[f'transmit_{i}' for i in range(3)]]
write_csv(out/'learner_advantages_by_action.csv',[dict(action=i,label=label,count=int((acts==i).sum()),mean=adv[acts==i].mean() if (acts==i).any() else None,minimum=adv[acts==i].min() if (acts==i).any() else None,maximum=adv[acts==i].max() if (acts==i).any() else None) for i,label in enumerate(labels)])
mask=np.stack([u['old_logits']>-1e8 for u in unique])
write_csv(out/'learner_masks.csv',[dict(action=i,label=label,valid_count=int(mask[:,i].sum()),valid_frequency=mask[:,i].mean(),selected_count=int((acts==i).sum())) for i,label in enumerate(labels)])
probs=readcsv(here/'retained_analysis_v2/action_distributions.csv')
for phase,audit in [('before',load(folder/'initial_policy_gate.json')['empty']),('after',r['initial_observation_policy_distribution'])]:
    probs+=distribution_rows(audit,version='v4',mode='conflict',iteration=0 if phase=='before' else 1,stage='fresh_local_audit',selection='frozen_reset',condition='reset',source=str(folder))
write_csv(out/'action_distributions.csv',probs)
replay=load(here/'cluster_final_replay.json')
assert all(sum(replay[m]['categorical_counts'])==65536 for m in ['conflict','continuous'])
write_csv(out/'v3_final_categorical_replay.csv',[dict(mode=m,action=i,label=labels[i],count=n,draws=65536,frequency=n/65536,seed=2701,scope='16 saved terminal probes, 4096 draws per probe') for m in ['conflict','continuous'] for i,n in enumerate(replay[m]['categorical_counts'])])
evals=readcsv(here/'retained_analysis_v2/evaluation_diagnostic.csv')
resources=readcsv(here/'retained_analysis_v2/resources.csv');tasks=readcsv(here/'retained_analysis_v2/task_durations.csv');checks=readcsv(here/'retained_analysis_v2/packet_reconciliation.csv')
for selection in ['deterministic','stochastic']:
    path=here/'v4_conflict_rollout_seed7001_v2'/f'{selection}_rollout.json';e=load(path)
    hs=[h for entries in e['resource_history'].values() for h in entries]
    evals.append(dict(version='v4',mode='conflict',selection=selection,iteration=1,seed=7001,horizon_s=1200,
        capture_coverage=e['coverage']['capture_coverage_fraction'],ground_coverage=e['coverage']['ground_delivery_coverage_fraction'],
        reward=sum(e['cumulative_reward'].values()),minimum_battery=min(h['battery_fraction'] for h in hs),maximum_storage=max(h['storage_fraction'] for h in hs),
        accepted_packets=e['message_diagnostics']['packet_outcome_counts'].get('accepted',0),source=str(path),initial_conditions_sha256=e['initial_conditions_sha256']))
    for sensor,entries in e['resource_history'].items():
        resources.extend(dict(version='v4',mode='conflict',selection=selection,seed=7001,sensor=sensor,**h) for h in entries)
for ei,e in enumerate(es):
    ctx=dict(version='v4',mode='conflict',selection='fresh_training_categorical',iteration=1,episode=ei)
    extract_events(e['coordination']['task_history'],e['transmissions'],e['packets'],ctx,tasks,checks,r['episodes'][0].get('config',load(folder/'checkpoint_0001/manifest.json')['config']))
write_csv(out/'evaluations.csv',evals);write_csv(out/'task_durations.csv',tasks);write_csv(out/'packet_reconciliation.csv',checks);write_csv(out/'resources.csv',resources)
v3=load(here/'v3_conflict_config.json');v4=load(folder/'checkpoint_0001/manifest.json')['config']
write_csv(out/'config_comparison.csv',[dict(parameter=k,v3=json.dumps(v3.get(k,'ABSENT')),v4_local=json.dumps(v4.get(k,'ABSENT')),changed=v3.get(k)!=v4.get(k)) for k in sorted(set(v3)|set(v4))])
summary=dict(unique_learner_decisions=len(unique),minibatch_presentations=row['minibatch_presentations'],repeated_presentations=row['minibatch_presentations']-len(unique),
    clip_fraction=row['clipping_fraction'],value_clamp_fraction_presentations=row['value_clamp_fraction_presentations'],
    standardized_advantage_mean=float(adv.mean()),standardized_advantage_std=float(adv.std()),value_target_range=[min(u['target'] for u in unique),max(u['target'] for u in unique)],
    observations_finite=bool(np.isfinite(obs).all()),observation_range=[float(obs.min()),float(obs.max())],
    action_counts=Counter(acts.tolist()),selected_empty_downlink=int(((acts==1)&(obs[:,0]<=1e-6)).sum()),
    caveat='One current-runtime local 1200-second update. Advantages are standardized, not raw. No attribution of these gradients to historical v3.')
(out/'learner_summary.json').write_text(json.dumps(summary,indent=2)+'\n')

plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150})
for mode in ['conflict','continuous']:
    c=[x for x in cluster if x['stage']=='four_worker_pilot' and x['mode']==mode];x=[int(t['iteration']) for t in c]
    fig,axs=plt.subplots(1,3,figsize=(12,3.7),constrained_layout=True)
    for ax,key,title,limits in [(axs[0],'normalized_entropy','Entropy / log(valid actions)',(.98,1.001)),(axs[1],'downlink_probability','Downlink probability',(0,.13))]:
        ax.fill_between(x,[float(t[key+'_min']) for t in c],[float(t[key+'_max']) for t in c],color='#4477aa',alpha=.25)
        ax.plot(x,[float(t[key+'_min']) for t in c],color='#4477aa');ax.plot(x,[float(t[key+'_max']) for t in c],color='#4477aa');ax.set(title=title,ylim=limits,xlabel='PPO update');ax.grid(alpha=.15)
    axs[2].plot(x,[json.loads(t['argmax_counts']).get('1',0)/16 for t in c],marker='o',color='#cc6677',label='downlink');axs[2].plot(x,[json.loads(t['argmax_counts']).get('4',0)/16 for t in c],marker='s',color='#4477aa',label='continue');axs[2].set(title='Argmax share of 16 probes',ylim=(0,1.05),xlabel='PPO update');axs[2].legend()
    fig.suptitle(f'v3 {mode}: changing terminal training probes, no mission evaluation');fig.savefig(out/f'v3_{mode}_probability_history.png');plt.close(fig)
    u=[u for u in updates if u['version']=='v3' and u['stage']=='four_worker_pilot' and u['mode']==mode]
    fig,axs=plt.subplots(1,2,figsize=(9,3.7),constrained_layout=True)
    for key,label in [('mean_acquisition_reward','Acquisition (90%)'),('mean_ground_reward','Ground delivery (10%)'),('mean_other_penalties_or_adjustments','Operational adjustments')]:axs[0].plot(x,[float(t[key]) for t in u],marker='o',label=label)
    axs[0].legend();axs[0].set(title='Mean reward per complete episode',xlabel='PPO update',ylabel='Reward')
    axs[1].plot(x,[float(t['maximum_storage_fraction']) for t in u],marker='s',label='Max storage');axs[1].plot(x,[float(t['minimum_battery_fraction']) for t in u],marker='o',label='Min battery');axs[1].legend();axs[1].set(title='Training resource extrema',xlabel='PPO update',ylabel='Fraction',ylim=(0,1.05));fig.suptitle(f'v3 {mode}: 45000-second sampled training');fig.savefig(out/f'v3_{mode}_reward_resources.png');plt.close(fig)
fig,axs=plt.subplots(1,3,figsize=(12,3.7),constrained_layout=True)
for offset,m,c in zip([-.18,.18],['conflict','continuous'],['#4477aa','#cc6677']):axs[0].bar(np.arange(18)+offset,np.asarray(replay[m]['categorical_counts'])/65536,width=.35,color=c,label=m)
axs[0].set(title='Final v3 categorical replay',xlabel='Action index',ylabel='Empirical frequency');axs[0].legend()
axs[1].plot([1,2,3],[d['value_clamp_fraction'] for d in minibatches],marker='o',label='Value loss clamped');axs[1].plot([1,2,3],[d['clipping_fraction'] for d in minibatches],marker='s',label='Policy ratio clipped');axs[1].set(title='Fresh local v4 loss diagnostics',xlabel='Minibatch',ylabel='Presentation fraction',ylim=(0,1));axs[1].legend()
for group in ['critic','operational_head','image_head','peer_head','actor_body']:
    gs=[g for g in grads if g['term']=='total' and g['group']==group];axs[2].plot([g['minibatch'] for g in gs],[g['unclipped_gradient_l2'] for g in gs],marker='o',label=group.replace('_',' '))
axs[2].set(title='Fresh v4 gradients before clipping',xlabel='Minibatch',ylabel='L2 norm',yscale='log');axs[2].legend(fontsize=7)
fig.savefig(out/'categorical_and_learner_diagnostics.png');plt.close(fig)
for selection in ['deterministic','stochastic']:
    e=load(here/'v4_conflict_rollout_seed7001_v2'/f'{selection}_rollout.json');fig,axs=plt.subplots(1,2,figsize=(9,3.8),constrained_layout=True)
    for sensor,hs in e['resource_history'].items():
        axs[0].plot([h['time_s'] for h in hs],[h['battery_fraction'] for h in hs],label=sensor)
        axs[1].plot([h['time_s'] for h in hs],[h['storage_fraction'] for h in hs],label=sensor)
    axs[0].set(title='Battery',xlabel='Simulation time (s)',ylabel='Fraction',ylim=(0,1));axs[0].legend(fontsize=8)
    axs[1].set(title='Storage',xlabel='Simulation time (s)',ylabel='Fraction',ylim=(0,1));fig.suptitle(f'v4 conflict, restored {selection}, seed 7001, 1200 seconds');fig.savefig(out/f'v4_seed7001_{selection}_resources.png');plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(8,3.7),constrained_layout=True)
axs[0].hist(adv,bins=12,color='#4477aa');axs[0].set(title='86 distinct standardized advantages',xlabel='Advantage',ylabel='Decisions')
axs[1].scatter([u['target'] for u in unique],[u['value'] for u in unique],color='#4477aa',s=18);axs[1].set(title='Value predictions vs targets',xlabel='Value target',ylabel='Value prediction');fig.suptitle('Fresh local v4 update: 1200 seconds');fig.savefig(out/'learner_credit.png');plt.close(fig)
print(json.dumps(summary))
