# Walker-4 PPO failure diagnosis — 29 September 2026

The demonstrated failure is an operationally unsafe deterministic policy, combined with an empty-downlink availability defect. It is **not evidence of categorical all-downlink collapse**. Reading the original cluster checkpoint tensors now closes that important historical evidence gap: the final conflict policy assigns downlink only 8.41–11.59% probability on its 16 saved terminal probes, despite argmax selecting it on all 16. Its normalized entropy is 0.9887–0.9932. Seeded categorical replay selects downlink 6835/65536 times (10.43%), with roughly 70.6% probability mass on imaging. These observations are terminal training probes, not held-out reset states or a stochastic full mission.

**Recommendation: run the prepared one-worker diagnostic gate only after explicit authorization and a cluster runtime/source preflight. Do not scale to four workers or a learned multi-seed comparison.** The smallest remaining useful experiment is one fresh, instrumented 45000-second conflict update followed by exact optimizer restore and paired restored stochastic/deterministic validation. Keep the existing v4 settings fixed. This tests operational recovery and exposes full-horizon credit/value diagnostics; it does not identify which of the several historical v4 tuning changes helped.

## Confirmed causes

1. **Argmax turns a broad distribution into a repeated harmful action.** v3 sampled training acquired images, delivered full products and sent directed metadata. Final held-out deterministic evaluation instead selected downlink at every decision on all five seeds per mode: mean 17951 downlink selections, zero capture and ground coverage, no accepted packets, and zero minimum battery. On saved conflict checkpoint probes, downlink argmax grows from 0/16 at updates 1–3 to 16/16 at update 8 while entropy stays near one. The final top-two logit gap ranges from 0.0151 to 0.2522. Continuous final probes have 7 downlink and 9 continue argmaxes, yet the same broad categorical behavior; all-downlink held-out behavior is therefore observation dependent. The evaluation measurement is valid for deterministic deployment. Generalizing it to stochastic collapse was unsupported.
2. **v3 allows downlink with no local physical data.** All four real reset observations have zero storage but nonzero downlink probability; the v3 initialized module chooses downlink on all four with probability 8.64–9.11%. A real controller test executes the empty downlink instead of rejecting it. The policy-mask and controller regression tests both fail against exact archived v3 and pass with an isolated empty-storage correction. This makes the deterministic bad loop possible: no acquisition replenishes storage, repeated attempts incur −1 penalties and consume simulation/resource time, and resource depletion does not force a useful new action in v3.

The smallest correction is in `minimal_empty_storage_fix.patch`: one shared storage tolerance, a schema bump, matching policy/random-sampler predicates and controller rejection, plus the policy regression. It changes no head initialization, entropy, gradient clip, reward, discount or task timing. It is tested in `empty_storage_fix_source/`, **not applied to the primary source**. The primary worktree already contains the broader v4 resource correction, which remains untouched. This patch fixes an invalid operational choice; it is not proof that the resulting argmax policy becomes useful.

## Contributing factors

- **Learning has not produced decisive state-dependent action preferences.** All eight v3 checkpoint terminal distributions remain broad. This is a lack of demonstrated useful discrimination, rather than lost categorical exploration. The pilot contains 32 full sampled episodes and 32080 policy decisions in conflict, and 32 episodes/63064 decisions in continuous. The requested batch minimum of 64 must not be described as 64 learned decisions per update. Those counts still do not establish convergence or adequate rare-state coverage.
- **Ground-delivery and communication credit is indirect and delayed.** Acquisition receives 90% of reward, full ground delivery 10%, and metadata communication no direct positive reward. The matched short runs reconcile 82 completion records: physical capture-to-completion delay is 8–9 s and task-start-to-completion delay is 38–122 s; reward observation boundaries match completion times. Some boundary rewards are zero because qualified acquisition need not earn new duplicate/revisit credit. Ordinary 300-second task duration retains 99.54% reward discount, so fast discounting at that duration is rejected. The GAE trace over a whole 45000-second mission retains only 0.276%, making long-delay credit reliant on value learning. Retained short runs have no ground services. Full v3 sampled episodes have positive delivery reward, but action-to-delivery advantage attribution was not retained. `analysis_final/credit_events.csv` and `discount_weights.csv` distinguish measured delays from theoretical weights.
- **Value learning is weak in the fresh local update.** Explained variance is 0.001014; value targets span −0.0049 to 8.0207 while predictions remain roughly −0.083 to −0.051. Ray 2.35 clamps squared value residuals at 10, and 39.58% of the 96 minibatch presentations hit that clamp, producing zero value-loss gradient on those residuals. Critic gradient norms exceed actor-head norms in each measured minibatch. Policy-ratio clipping is zero and KL is about 5.69e−8. These are direct findings for the new local v4 regression, **not a recovered historical v3 gradient diagnosis**. No value-loss tuning was applied.
- **Storage is saturated during v3 sampled training.** Maximum storage reaches capacity, although full-storage penalty is zero. v3 deterministic failure starts from empty storage; these are different resource regimes. The v4 5% battery start guard also does not budget energy through a full task, and active continue is intentionally exempt. Short healthy trajectories cannot certify mission-long resource safety.
- **v4 changed several variables at once.** Operational masks, calibrated heads, entropy coefficient 0.02 and global gradient clip 1.0 coexist with shorter local horizons/deadlines. Capture improvement in those local runs cannot isolate a correctness fix from initialization/tuning or establish full-horizon recovery.

## Rejected hypotheses, within tested scope

| Hypothesis | Evidence and limit |
|---|---|
| Final stochastic distribution collapsed to downlink | Rejected on the original saved terminal probes by exact softmax and 4096 draws per probe. Full restored stochastic v3 mission remains unrun. |
| Corrupt policy export/restore explains the deterministic result | Historical restores have zero logit error and matching actions; final remote file digests match manifests. New local v4 restore also has zero error. |
| Training and inference use different structural masks | Same `pi()` implementation, exact logits across train/explore/inference in schema-compatible probes. v4 real resource/controller checks agree. This does not reconstruct every historical learner state. |
| Physical directed communication never works | 879 conflict and 721 continuous accepted v3 training packets; all recipient/hold checks reconcile after accounting for ACK filtering. v4 retained packet checks pass, and the fresh training update accepts four packets, two per episode. |
| Six differing payloads imply transport corruption | Rejected: 873/879 conflict packets initially matched identical hold payloads, all 721 continuous packets matched. The six reduced payloads remove 262 records already acknowledged during the physical hold. Every removed ID has a matching accepted receipt on that link during the hold. `_queue()` intentionally re-filters the frozen payload against updated sender-local ACK state. No TTL explanation is needed. |
| NO_ACTION is necessarily credited as a policy choice | Connector/discounting tests pass; the fresh learner contains 86 actual decisions and no forced plumbing action. Explicit continue and forced NO_ACTION remain distinct. |
| Target or peer ordering breaks permutation consistency | Tensor permutation tests and frozen probes pass, with maximum errors at most about 3e−8 for v3 initialization and 1e−9 for restored v4 probes. This does not prove learned expressivity. |
| NaNs or gross observation corruption explain the new local update | All retained learner observations finite, range −2.654 to 2.779; masks and selected actions valid; standardized advantages mean approximately zero/std one. Geometric/time scales can exceed one by design. |
| Optimizer is reset on the new local restore | Exact Adam digest and training iteration restore passed without another `train()` call. |

## Remaining uncertainty and ranked falsifying tests

| Rank | Unresolved hypothesis | Smallest decisive test |
|---|---|---|
| 1 | A broad restored stochastic policy may still fail mission resource/delivery constraints | Prepared one-worker 45000-second gate, with every actual decision and resource boundary retained. Require the stochastic policy to satisfy all thresholds below. |
| 2 | Full-horizon value/credit scaling prevents useful PPO preferences | In that same single update, retain value targets, raw/standardized advantages where available, duration/reward times and gradient contributions. Compare clamped residual fraction, value fit and credit by operational/image/peer class. A later tuning experiment must vary one setting at a time. |
| 3 | Too little diversity or ineffective rare-action credit | The same gate reports distinct decisions, repeat presentations, mask opportunities and advantage counts for peer/downlink/charge actions. If mechanically healthy but ineffective, prepare a single-variable/seed replication, not an immediate four-worker run. |
| 4 | Near-zero sensitivity or missing representation prevents meaningful choices | Paired feature changes already produce nonzero logits with unchanged masks, including own battery, task state, target priority/position and peer beacon position. Their small size is expected after calibrated initialization. Compare learned logits/embeddings on fixed meaningful pairs after the full-horizon update. |
| 5 | A rarer asynchronous/catalog timing bug corrupts some mission experience | Extend event reconciliation to every decision, physical exposure completion, receipt and reward timestamp in the gate. Existing packet/connector tests falsify the broad version, not every rare interaction. |

Historical v3 raw update records **do not contain learner entropy, KL, ratio-clipping fractions, value explained variance, advantages or per-head gradients**. A checkpoint cannot reconstruct the exact sampler batch and loss history. The raw 90 MB conflict history and all eight checkpoints exist and were read through authenticated Termius; separate SFTP authentication failed, so full raw files were not downloaded. New cluster measurements in this package are explicitly marked manual stdout transcriptions with six-decimal ranges. `remote_readonly_probe.py` regenerates full-precision observations/logits/probabilities/group entropies/draws directly from those originals. The historical optimization cause cannot be uniquely identified from the retained evidence.

## Reproduction ladder and failure-tree updates

| Experiment | Result | Failure-tree change and next choice |
|---|---|---|
| Provenance/runtime audit | Local Ray 2.35/Torch 2.4.1 match major historical packages; Basilisk build differs | Historical simulator equivalence is unproven; use local tests as regressions, read original cluster tensors for A. |
| Pure tensor/connector tests | 16 focused tests pass | Broad mask-path/permutation/NO_ACTION defects reduced; probe real states. |
| Archived v3 real reset + 4096 draws/sensor | 232/18 valid; all four downlink argmax, but 8.6–9.1% probability and entropy >0.997 | A and empty-downlink branch B supported; distinguish final trained policy next. |
| Original 20 checkpoint probe tables + final categorical replay | Distributions remain broad; conflict argmax shifts to downlink; exact final hashes match | Reject categorical collapse on probes; no full stochastic performance inference. |
| Restored v4 reset/path/permutation probes | Exact restore, same masked logits in all three paths | Verify state-local safety with physical observations. |
| Real v4 physical states | 28 rows across reset, actual products/active task, low battery, active low-battery charging, each peer slot | Charge/continue escapes and useful slots verified; peer tests use controlled catalog/ideal-link fixtures, not natural LOS coverage. |
| Matched 1200-second restored rollout, seed 7001 | Deterministic: 55 decisions, 29% capture; stochastic: 45 decisions, 26% capture. Both: zero ground deliveries and accepted packets, no empty downlink | Short capture is reproduced but no operational mission gate is passed. Original seed 7000 accepted stochastic packets, showing seed sensitivity. |
| Empty-downlink reproducer before/after | Policy mask and real controller fail archived v3 and pass isolated correction; current v4 passes | Minimal correctness patch prepared; keep speculative tuning separate. |
| One fresh local PPO update | Two complete 1200-second episodes; 86 distinct decisions, 96 presentations, finite losses/gradients, nonzero parameter delta, four accepted packets | Learning mechanics pass; value clamp/credit concern grows. Earlier commentary count 89 referred to the older retained v4 update, not this fresh one. |
| Post-update probes and optimizer restore | Exact logits/actions, same broad reset distribution, exact Adam digest/counter restoration | Export/resume defect rejected locally; the full-horizon gate is now prepared. |
| Cluster packet reconciliation | All 1600 accepted packets explainable by holds and sender-local ACK updates | Broad transport failure rejected; record ACK-filtering semantics in gate checks. |

Controlled feature probes are not all naturally occurring mission states. The peer fixtures inject one qualified catalog record, mark other links acknowledged, and use ideal connectivity with physical Walker positions. They exercise the actual observation builder and exact receiver slot encoding. Physical-product and low-battery states use actual Basilisk storage and battery messages, with owned/qualified product counts retained explicitly. See `physical_probe_final.json`. Earlier numbered physical-probe files refer to audit harness attempts, not historical schema versions.

## One-worker gate and pass/fail thresholds

`one_worker_gate.py` prints its plan by default. `--execute` intentionally runs one remote environment runner, one fresh full-horizon update, optimizer restore without another update, and paired restored validation at seed 7101. Training seed is 7100. Neither reserved held-out seeds 10000–10004 nor old result directories are reused. `gate.slurm` is prepared and syntax checked; it has not been submitted or run.

Every stochastic validation must reach 45000 s; produce at least one qualified exposure and at least one full qualified owned ground delivery; keep sampled boundary battery fraction ≥0.05 and storage fraction <0.95; use at least two **action classes**; select at least one recipient and receive at least one accepted packet; make zero empty-storage downlink choices; use valid masks; and reconcile decision counts. Accepted packets must follow the selected receiver's physical hold, allowing records removed by ACK re-filtering. Training episodes must also complete the horizon with finite gradients and the same battery/storage margins. Restore logit error must be ≤1e−6 and Adam moments/counters/iteration must match exactly. Deterministic results are recorded separately and do not substitute for stochastic gate results.

These margins are declared operational screening thresholds, not empirically optimized performance targets. Resources are sampled at simulator boundaries; this package does not claim continuous-time minima. A one-seed pass permits further diagnosis, not a convergence, superiority or deployment claim. A failure leaves four-worker expansion blocked pending a specific diagnosis.

Within an explicitly authorized cluster allocation, after staging reviewed v4 source and a verified compatible Basilisk build, the exact command is:

```bash
cd /projects/dahu1128/bsk_rl-multi-agent-space-imaging-2026
PYTHONPATH=src:. /projects/dahu1128/.venv-completion-v2/bin/python \
  examples/multiagent_imaging/cluster/evidence/walker4_failure_audit_20260929/one_worker_gate.py \
  --config examples/multiagent_imaging/configs/walker4_mixed_preflight_conflict.json \
  --output /scratch/alpine/dahu1128/walker4-failure-audit-gate-20260929 \
  --execute
```

The cluster checkout was historically v3; this command is **not ready to execute until its v4 source, native Basilisk modules, package versions and support-data hashes are checked in the allocation**. The reviewed Slurm wrapper sets the native GCC runtime, isolated Ray socket path and support-data audit. No cluster job, four-worker run, push, or historical overwrite occurred in this audit.

## Evidence package

- `CONTRACT.md`: exact feature/action, mask, reward, timing, optimizer and v3/v4 behavior map.
- `analysis_final/updates_diagnostic.csv`: all 20 v3 gate/pilot updates, two historical v4 local updates and the new local update. Terminal probe quantities are named separately from learner quantities.
- `analysis_final/`: probability histories, reward/resource plots, learner arrays-derived masks/advantages/feature ranges/gradients, evaluation table, packet checks, measured credit delays and credit plot. `availability.csv` is the final metric-availability map; the intermediate `retained_analysis_v2/availability.csv` predates cluster access and is superseded. Original plot series never combine training, deterministic deployment and stochastic deployment. The two `retained_analysis_v2/v3_*_updates.png` figures retain loss, gradient and sample-count histories with the one-worker and four-worker policies labeled separately.
- `failure_tree.json`, `cluster_reconciliation_summary.json`: seven tested branches and reconciled historical packet totals.
- `cluster_*transcription.*`: labeled read-only live cluster results; exact final tensor hashes and replay counts.
- `local_update_v2/`: untouched new raw PPO checkpoint, optimizer state, learner NPZ/JSON batches, episodes, reproduction snapshot and initial/post-update audits.
- `probe.py`, `physical_probe.py`, `rollout_probe.py`, `learner_probe.py`, `resume_probe.py`, `paired_sensitivity.py`: executable bounded reproducers.
- `minimal_empty_storage_fix.patch`, isolated corrected source, before/after regression logs: proven correction only.
- `REPRODUCE.md`, `preservation_check.json`, `artifact_manifest.json`: commands and preservation/integrity evidence.

All 177 protected historical evidence files match their starting hashes, and the tracked pre-existing patch remains byte-identical. Of 101 initially fingerprinted source files, 100 still match. The unrelated, untracked `examples/multiagent_imaging/visualize_baseline_comparison.py` changed during the audit; this audit did not edit or import it. Its before/after hashes are recorded, and it is left untouched. The training, controller, observation, configuration and checkpoint files used here retain their starting hashes. The whole-checkout fingerprint therefore must not be described as unchanged.

Failed harness attempts and logs remain in the audit directory for provenance. They include a guessed test filename, a value-tensor indexing error, an unsupported learner-config setter, an audit JSON-key mismatch, an over-specific exception-message assertion, a heartbeat changed on the environment but not its simulator, and terminal indentation/clipboard handling. Corrected fresh output directories are named above. None of these harness failures is attributed to PPO or Basilisk.
