# Experiment contract reconstructed from executable source

Baseline: BSK-RL `9ec3071ca5dd481e098b28cd84b813a035286789`, archived in `v3_source/`. Current worktree: `e7b0d40988770ac8618bdd9392b087ea6dec2c19` plus the pre-existing v4 patch. The committed experiment implementation is unchanged between those commits; the intervening commit adds pilot aggregation, evidence and documentation. `source_before.patch` records the pre-existing dirty changes. All current probes use that v4 source. Never load a v3 checkpoint through v4 source.

## Observation and action map

Four shared-policy sensors see `26 + 10*17 + 3*12 = 232` float32 features and 18 actions. The 100 passive targets propagate in Basilisk but never enter the RL agent dictionary. Walker geometry is 4/2/1, 700 km, 97 degrees; targets are exactly 50 LEO, 30 MEO and 20 GEO.

| Flat indices | Ordered features | Scale |
|---|---|---|
| 0–1 | Own storage, battery | Capacity fractions |
| 2–4 | Own wheel speeds | Max wheel speed fractions |
| 5–7 | Own Sun direction in Hill axes | Unit vector |
| 8–9 | Eclipse start/end | 5700 s |
| 10–13 | Two ground-window open/close pairs | 5700 s |
| 14–18 | Own charge/downlink/desat/transmit/image task indicators | Binary |
| 19–21 | Task elapsed, remaining, pointing-hold fraction | 12000 s; hold capped at 1 |
| 22–25 | Sender unacknowledged fraction, last exchange age/known, continue valid | Catalog fraction; 12000 s; binary |
| 26–195 | Ten target slots, 17 values each | See below |
| 196–231 | Three peer slots, 12 values each | See below |

Target order: priority/10; relative position in own Hill axes/15960 km (3); inertial velocity difference expressed in own Hill axes/12000 m/s (3); pointing angle/90 degrees; range/15960 km; illumination; latest acquisition age/12000 s and known; freshest delivered capture age/12000 s and known; own pending product; own active target; valid slot. This velocity is an inertial velocity difference expressed in Hill axes, not the derivative in a rotating frame.

Peer order: navigation-beacon relative position/15960 km (3); inertial velocity difference in own Hill axes/12000 m/s (3); boresight angle/180 degrees; range/15960 km; sender delta/catalog size; last pair exchange age/12000 s; exchange known; valid slot. Peer slots follow lexical sensor-name order excluding self. Validity requires a surviving discovered contact and a sender-local unacknowledged qualified completion delta. No private peer battery, storage or intent is read by the actor.

Candidates are eligible receiver-local catalog targets, first the existing ascending-elevation shortlist within −21 to 90 degrees, then nearest eligible fill. Cooldown and unresolved captures remove targets. Empty slots are explicit zero/None padding. A valid candidate is a legal task request, not a guarantee of immediate physical visibility or imaging success. Candidate and peer snapshots are cached at the observation timestamp and used by action decoding.

| Action | Meaning |
|---|---|
| 0 | Charge |
| 1 | Downlink owned physical products |
| 2 | Desaturate |
| 3 | Reserved broadcast slot, masked in directed mode |
| 4 | Deliberately continue the current active task |
| 5–14 | Image target candidate slots 0–9 |
| 15–17 | Point and transmit to peer slots 0–2 |

v3 masks invalid target slots, unavailable peers, inactive continue, and reserved broadcast. It leaves downlink valid with empty storage and powered tasks valid at low battery. v4 adds `storage > 1e-6` for downlink and `battery > 0.05` for newly started powered tasks. Charge remains valid; active continue remains valid. The same predicates operate in the module, masked random sampler, and controller. A fixed 5% reserve is a start-state predicate, not a duration-aware guarantee of surviving every task.

## Policy and trajectory paths

`make_shared_policy_mapping` accepts only sensing IDs and maps each to `imager`. Float32 features reach `GNNModule` through the RLlib environment/learner connectors; no learned observation standardizer is configured. Target/own encoders feed target attention; a permutation-consistent peer set head adds peer scores and pooled peer conditioning. The critic has separate parameters.

Training and exploration call the same `pi()` masking logic and sample a categorical distribution. Inference uses the same masked logits and categorical distribution converted to deterministic selection. Export stores weights, actual probe observations and expected logits; restore validates schema, digest and logits with strict state loading. Standalone deterministic evaluation uses argmax; stochastic evaluation exponentiates the same shifted logits and uses a seeded NumPy categorical draw. Both paths consume the same feature order. Tensor path equality and target/peer permutation checks passed for their schema-compatible sources.

Forced `NO_ACTION` when a sensor is busy is connector/controller plumbing. `CondenseMultiStepActions` folds its time and discounted rewards into the initiating decision and removes it from the learner. Explicit action 4 remains a policy decision. Evaluation's label `continue` can include forced `NO_ACTION`; use retained decision tensors or `policy_decisions` to count actual policy choices. Complete-episode batches avoid fragmenting away the initiating log probability.

Conflict mode retasks on physical completion or receiver-local completion invalidation. Continuous mode exposes every boundary, allowing interruption. Continuing or selecting the same active physical target/receiver preserves the hold; switching interrupts it. Step order is action application → physical propagation → local data/reward updates → communication/catalog merges → retasking and next observations. Metadata receipt does not transfer physical products or ground-delivery ownership.

## Reward, timing and PPO

Reward is 90% qualified acquisition credit plus 10% full owned ground-delivery credit. Quality threshold is 0.5. Captures publish only after exposure resolution; partial storage drainage earns no full-product delivery. Cooldown is capture anchored, two orbital periods (11834.835756586714 s). Empty downlink costs −1 per attempt. Failure penalty is −1. Configured low-battery, full-storage, duplicate and per-second communication penalties are zero. Catalog completion packets have no direct positive reward.

The mission horizon is 45000 s, physical integration is 1 s, heartbeat and image/downlink/charge deadlines are 300 s, desat 150 s, directed transmit deadline 300 s and minimum hold 10 s. The v4 local configurations use 1200 s, 180 s heartbeat/image/charge and 120 s downlink/desat; they cannot establish full-mission performance.

`gamma = exp(log(0.5)/45000)` per second, `lambda = exp(log(0.5)/6000)` per second. Rewards condense to step-start time. GAE uses measured action durations, including `gamma**dt` and `lambda**dt`. Advantages are standardized across the shared module, with standard deviation floor 1e-4. A 300 s endpoint keeps 99.54% of its discounted reward and 96.15% of its gamma-lambda trace; at 45000 s these are 50% and 0.276%. Long-range credit therefore depends on the critic, rather than direct trace propagation alone.

PPO: learning rate 3e-5, requested minimum batch 64 environment steps, complete episodes, minibatch 32, one SGD epoch, clip parameter 0.3, KL enabled (default initial coefficient 0.2, target 0.01), value coefficient 1, value-loss clamp 10. The minimum 64 is not the effective number of decisions: v3 four-worker updates collect thousands. In Ray 2.35 the value clamp caps squared residuals, and residuals beyond that cap have zero value-loss gradient. This is different from clipping changes to the value prediction.

## v3 → v4 comparison

| Parameter/behavior | v3 | Existing v4 | Interpretation |
|---|---|---|---|
| Semantic version | completion-v3-walker4-mixed | completion-v4-operational-mask | Incompatible checkpoint contract |
| Downlink availability | Any storage | Own storage > 1e-6 and battery > 0.05 | Empty-storage fix plus resource guard |
| Other new powered tasks | No battery predicate | Battery > 0.05 | Resource guard; duration safety unproven |
| Charge/active continue | Available under original rules | Same | Escape/continuation maintained |
| Actor image and operational output initialization | PyTorch defaults | Orthogonal gain 0.01; image bias 0.01, operational bias 0 | Initialization tuning |
| Final peer output initialization | PyTorch defaults | Orthogonal gain 0.01, bias 0 | Initialization tuning |
| Entropy coefficient | Default 0 | 0.02 | Optimization tuning |
| Gradient clip | Default none | Global L2 1.0 | Optimization tuning |
| Policy restore construction | Consumes Torch RNG | Restores prior Torch RNG after construction | Reproducibility change |
| Schema metadata | Original order/population/geometry | Adds operational thresholds/version | Restore validation |
| Random sampling and execution | Original structural mask | Mirrors resource predicates, rejects violations | Path consistency |
| Audit retention | Episode summaries, probes, losses, global gradients, checkpoints | Adds action counts, learner scalars, frozen reset logits/probabilities/masks/draws, hyperparameters | Evidence expansion |
| Evaluation/gate | Deterministic restored policy | Also seeded stochastic evaluation and probability initialization gate | Additional measurement, not recovery proof |
| Local horizon/deadlines | Mission settings | Short configurations above | Confound, not a mission recovery |

Reward, time discount, GAE, architecture topology, mapping, target/peer slot order, physical ownership, candidate selection and retasking semantics otherwise remain unchanged. `analysis_final/config_comparison.csv` lists every serialized configuration field, including unchanged values. The source patch and preservation manifest retain every pre-existing source change; documentation changes do not change the executable contract.
