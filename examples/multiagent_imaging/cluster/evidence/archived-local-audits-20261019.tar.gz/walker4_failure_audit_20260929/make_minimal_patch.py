"""Prepare an isolated empty-storage correction against exact v3; no main edits."""
from pathlib import Path
import argparse,difflib,shutil

here=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--source-output',type=Path,default=here/'empty_storage_fix_source')
parser.add_argument('--patch-output',type=Path,default=here/'minimal_empty_storage_fix.patch')
args=parser.parse_args()
base=here/'v3_source'; fixed=args.source_output
assert not fixed.exists() and not args.patch_output.exists(), 'Choose fresh output paths'
shutil.copytree(base,fixed,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))

def edit(path,old,new):
    f=fixed/path;s=f.read_text();assert s.count(old)==1,(path,old);f.write_text(s.replace(old,new))

obs='src/bsk_rl/obs/completion_observations.py'
edit(obs,'OBSERVATION_VERSION = "completion-v3-walker4-mixed"','OBSERVATION_VERSION = "completion-v3-empty-storage-shield"\nEMPTY_DOWNLINK_STORAGE_EPS = 1e-6')
gnn='src/bsk_rl/utils/rllib/target_gnn_module.py'
edit(gnn,'                OBSERVATION_VERSION,','                OBSERVATION_VERSION,\n                EMPTY_DOWNLINK_STORAGE_EPS,')
edit(gnn,'            mask = torch.ones_like(logits, dtype=torch.bool)','            mask = torch.ones_like(logits, dtype=torch.bool)\n            mask[:, 1] = features[:, 0] > EMPTY_DOWNLINK_STORAGE_EPS')
train='examples/multiagent_imaging/train.py'
edit(train,'    peer_snapshot,','    peer_snapshot,\n    EMPTY_DOWNLINK_STORAGE_EPS,')
edit(train,'                    1,\n                    1,\n                    1,','                    1,\n                    int(sensor.dynamics.storage_level_fraction > EMPTY_DOWNLINK_STORAGE_EPS),\n                    1,')
controller='src/bsk_rl/completion_gym.py'
edit(controller,'    can_continue,','    can_continue,\n    EMPTY_DOWNLINK_STORAGE_EPS,')
edit(controller,'            self.decision_counts[sensor.name] += 1','            if action == 1 and sensor.dynamics.storage_level_fraction <= EMPTY_DOWNLINK_STORAGE_EPS:\n                raise ValueError("Downlink is masked while own storage is empty.")\n            self.decision_counts[sensor.name] += 1')
test='tests/unittest/multiagent/test_empty_downlink_audit.py'
(fixed/test).parent.mkdir(parents=True,exist_ok=True)
(fixed/test).write_text((here/'test_empty_downlink.py').read_text())
parts=[]
for p in [obs,gnn,train,controller,test]:
    old=(base/p).read_text().splitlines(keepends=True) if (base/p).exists() else []
    new=(fixed/p).read_text().splitlines(keepends=True)
    parts.extend(difflib.unified_diff(old,new,fromfile='a/'+p,tofile='b/'+p))
with args.patch_output.open('x') as f:f.writelines(parts)
print('Prepared isolated correction: policy, random sampler, controller, schema, regression; no tuning changes.')
