"""Add scope/availability, failure-tree and physical-credit tables; no simulation."""
import argparse,csv,json,math
from pathlib import Path

here=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,default=here/'analysis_final')
parser.add_argument('--metadata-output',type=Path,default=here)
args=parser.parse_args()
out=args.output;meta=args.metadata_output
out.mkdir(parents=True,exist_ok=True);meta.mkdir(parents=True,exist_ok=True)


def write_json(path,data):
    with path.open('x') as f:json.dump(data,f,indent=2,allow_nan=False);f.write('\n')


def write_csv(path,rows):
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)


branches=[
    dict(branch='A',hypothesis='Deterministic evaluation artifact',status='Argmax amplification confirmed; categorical collapse rejected on saved terminal probes',
         evidence=['cluster_final_replay.json','cluster_checkpoint_transcription.csv','v3_initial_probe.json'],
         limit='No restored stochastic full v3 mission was executed',next_test='One-worker restored stochastic full-horizon gate',rank=1),
    dict(branch='B',hypothesis='Action availability and mask-path defect',status='Empty downlink defect confirmed in archived v3; isolated policy/controller correction passes',
         evidence=['mask_before.log','controller_v3_source.log','mask_minimal_fix.log','controller_empty_storage_fix_source.log','physical_probe_final.json'],
         limit='The reserve guard does not predict task energy use',next_test='Full-horizon resource/action boundary screening',rank=1),
    dict(branch='C',hypothesis='Reward and credit assignment',status='Delayed/indirect rewards and weak fresh value fit observed; historical cause unresolved',
         evidence=['CONTRACT.md','analysis_final/credit_events.csv','analysis_final/discount_weights.csv','analysis_final/learner_advantages_by_action.csv'],
         limit='Historical raw advantages absent; current local learner retained standardized advantages only; no short-run ground delivery',
         next_test='Retain full-horizon targets, advantages, reward times and per-class credit',rank=2),
    dict(branch='D',hypothesis='Optimization instability or insufficient data',status='Finite nonzero historical global gradients and exact restores; current local value clamp observed',
         evidence=['analysis_final/updates_diagnostic.csv','analysis_final/gradient_contributions.csv','optimizer_resume.json'],
         limit='Historical per-head gradients, KL, clipping and value fit not retained; Adam counters per historical update not transcribed',
         next_test='One diagnostic update with fixed settings; later one-variable/seed experiment only if indicated',rank=3),
    dict(branch='E',hypothesis='Architecture or observation failure',status='Gross NaNs, path disagreement and slot permutation inconsistency rejected in tested scope',
         evidence=['tensor_tests.log','paired_sensitivity.json','analysis_final/learner_observation_features.csv'],
         limit='Nonzero feature sensitivity does not establish useful learned decisions',next_test='Fixed-pair learned logits/embeddings after full-horizon update',rank=4),
    dict(branch='F',hypothesis='Controller or asynchronous catalog failure',status='Empty controller action confirmed; broad communication/NO_ACTION failures rejected',
         evidence=['controller_v3_source.log','tensor_tests.log','cluster_reconciliation_summary.json','analysis_final/credit_events.csv'],
         limit='Packet data were read through Termius, not downloaded; rare interactions remain possible',
         next_test='Full gate event reconciliation, including ACK filtering, physical exposure and reward boundaries',rank=5),
    dict(branch='G',hypothesis='Resource feedback loop',status='v3 deterministic downlink loop and depletion confirmed; v3 sampled storage saturation observed',
         evidence=['analysis_final/evaluations.csv','analysis_final/v3_conflict_reward_resources.png','physical_probe_final.json'],
         limit='Short v4 health is not mission safety; resource values are boundary sampled',next_test='Full-horizon battery/storage margins and zero empty downlink',rank=1),
]
write_json(meta/'failure_tree.json',dict(branches=branches,
    iteration_history='REPORT.md reproduction-ladder table gives chronological evidence changes and next-test choices',
    final_choice='Prepare one-worker 45000-second gate; do not execute or submit without explicit approval'))

rows=[]
def available(version,metric,status,scope,source):
    rows.append(dict(version=version,metric=metric,availability=status,scope=scope,source=source))

for metric in ['policy_loss','value_loss','global_gradient_norm','parameter_delta','reward_components','policy_decisions','resource_extrema','restore_equivalence']:
    available('v3',metric,'retained_per_update','20 gate/pilot updates','analysis_final/updates_diagnostic.csv')
for metric in ['terminal_probe_argmax','terminal_probe_downlink_probability','terminal_probe_normalized_entropy','terminal_probe_image_group_mass']:
    available('v3',metric,'recomputed_manually_transcribed','20 checkpoint tables; changing terminal observations, six-decimal ranges','cluster_checkpoint_transcription.csv')
for metric in ['per_action_categorical_counts','valid_action_count','top_two_logit_gap','policy_hash']:
    available('v3',metric,'recomputed_final_only','16 terminal probes per final policy, seed 2701, 4096 draws per row','cluster_final_replay.json')
for metric in ['all_logits_probabilities','conditional_group_entropy']:
    available('v3',metric,'regenerator_available_not_locally_retained','Raw tensor checkpoints exist remotely; no raw download; remote_readonly_probe.py prints full precision','remote_readonly_probe.py')
for metric in ['learner_entropy','learner_kl','ratio_clipping','explained_variance','raw_advantages','standardized_advantages','per_head_gradient','learner_mask_frequency','full_learner_observations']:
    available('v3',metric,'not_retained_not_reconstructible_from_checkpoint','Raw update keys inspected remotely; sampler/loss history absent','REPORT.md Remaining uncertainty')
available('v3','optimizer_digest','retained_final_only','Final manifests per mode; intermediate optimizer states exist remotely but not transcribed','checkpoint_manifests in immutable v3 package')
available('v3','physical_event_reconciliation','recomputed_manually_transcribed','16 four-worker updates; 1600 accepted packets and six ACK-filtered payloads','cluster_event_transcription.csv and cluster_ack_filter_transcription.csv')
for metric in ['entropy','entropy_coefficient','kl','explained_variance','unclipped_value_loss','optimizer_digest','effective_decisions']:
    available('v4_historical_local',metric,'retained_per_update','Two 1200-second updates, one per mode','analysis_final/updates_diagnostic.csv')
for metric in ['raw_advantages','standardized_advantages','clipping_fraction','per_head_gradient','learner_mask_frequency']:
    available('v4_historical_local',metric,'not_retained','Two historical updates; do not substitute fresh diagnostics','REPORT.md')
for metric in ['standardized_advantages','value_targets','selected_actions','observations','old_new_logits','ratio_clipping','value_clamp_fraction','per_head_gradient','learner_mask_frequency']:
    available('v4_fresh_local',metric,'retained_full_learner_batch','86 distinct decisions, 96 presentations, three minibatches','local_update_v2/learner_batches')
available('v4_fresh_local','raw_advantages','not_retained','DiagnosticLearner sees already standardized advantages','learner_probe.py')
available('all','natural_state_mask_frequency','partially_retained','Fresh local learner complete; v3/v4 reset and controlled physical fixtures; no historical whole-batch masks','analysis_final/learner_masks.csv and physical_probe_final.json')
available('all','continuous_time_resource_extrema','not_retained','Boundary telemetry only; do not infer unsampled minima','analysis_final/resources.csv')
write_csv(out/'availability.csv',rows)

events=list(csv.DictReader((here/'cluster_event_transcription.csv').open()))
acks=list(csv.DictReader((here/'cluster_ack_filter_transcription.csv').open()))
summary={}
for mode in ['conflict','continuous']:
    es=[e for e in events if e['mode']==mode];rs=[e for e in acks if e['mode']==mode]
    n=sum(int(e['accepted_packets']) for e in es);strict=sum(int(e['exact_payload_and_hold_matches']) for e in es)
    assert strict+len(rs)==n and all(int(e['unexplained_records'])==0 for e in rs)
    assert all(float(e['mean_duration_s'])>0 and float(e['max_duration_s'])==300 for e in es)
    summary[mode]=dict(accepted_packets=n,strict_payload_matches=strict,ack_filtered_packets=len(rs),
        explained_removed_records=sum(int(e['removed_records']) for e in rs),unexplained_records=0,reconciled_packets=n)
write_json(meta/'cluster_reconciliation_summary.json',dict(modes=summary,
    source='Authenticated Termius read-only stdout manually transcribed; originals remain remote',
    algorithm='remote_events_probe.py checks physical hold, directed pair, payload subset, receipts during hold',
    caveat='No full raw-file transfer; arithmetic checks here validate transcriptions, not independent full-precision rereading'))

gamma=math.exp(math.log(.5)/45000);lam=math.exp(math.log(.5)/6000)
weights=[dict(duration_s=t,reward_weight=gamma**t,gae_trace_weight=(gamma*lam)**t,scope='Theoretical time contract')
         for t in [1,8,10,120,150,180,300,1200,6000,45000]]
write_csv(out/'discount_weights.csv',weights)
credit=[]
for selection in ['deterministic','stochastic']:
    path=here/'v4_conflict_rollout_seed7001_v2'/f'{selection}_rollout.json';e=json.loads(path.read_text())
    tasks=e['coordination']['task_history']
    for sensor,records in e['completion_records'].items():
        for r in records:
            if r['source_sensor']!=sensor:continue
            candidates=[t for t in tasks if t['sensor']==sensor and t['mode']=='image'
                and t['target_id']==r['target_id'] and t['start']-1e-6<=r['capture_time']<=t['end']+1e-6]
            assert len(candidates)==1,(selection,r['record_id'],len(candidates))
            task=candidates[0];delay=r['completion_time']-task['start']
            rewards=[x for x in e['reward_history'][sensor] if abs(x['time_s']-r['completion_time'])<1e-6]
            assert len(rewards)==1 and delay>=0
            credit.append(dict(selection=selection,seed=7001,horizon_s=1200,sensor=sensor,record_id=r['record_id'],
                target_id=r['target_id'],task_start_s=task['start'],capture_s=r['capture_time'],completion_s=r['completion_time'],
                capture_to_completion_s=r['completion_time']-r['capture_time'],task_to_completion_s=delay,
                physical_task_end_s=task['end'],reward_boundary_s=rewards[0]['time_s'],
                sensor_boundary_reward=rewards[0]['reward'],qualified=r['qualified'],quality=r['quality'],
                delivery_s=r['delivery_time'],reward_discount_weight=gamma**delay,gae_trace_weight=(gamma*lam)**delay,
                source=str(path),scope='Boundary reward may aggregate/zero duplicate credit; not individual record reward'))
write_csv(out/'credit_events.csv',credit)
write_json(out/'credit_summary.json',dict(records=len(credit),
    completion_delays_s=[min(r['capture_to_completion_s'] for r in credit),max(r['capture_to_completion_s'] for r in credit)],
    task_to_completion_s=[min(r['task_to_completion_s'] for r in credit),max(r['task_to_completion_s'] for r in credit)],
    reward_boundaries_match_completion=True,full_ground_deliveries=sum(r['delivery_s'] is not None for r in credit),
    caveat='Two matched short seed-7001 runs on current local runtime; historical full-mission credit/ground delay remains unknown'))
print(json.dumps(dict(failure_branches=len(branches),availability_rows=len(rows),credit_events=len(credit),packet_summary=summary)))
