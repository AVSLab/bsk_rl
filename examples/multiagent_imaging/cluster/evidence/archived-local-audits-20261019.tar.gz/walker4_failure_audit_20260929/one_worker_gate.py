"""Prepare by default. --execute intentionally runs one worker, one PPO update.

Run only inside an explicitly authorized allocation. No submissions occur here.
This evaluates existing v4 settings, not the isolated v3 correctness patch.
"""
import argparse,json,os
from dataclasses import replace
from pathlib import Path

THRESHOLDS=dict(horizon_s=45000,minimum_battery_fraction=.05,maximum_storage_fraction=.95,
    minimum_qualified_exposures=1,minimum_full_qualified_ground_deliveries=1,
    minimum_action_classes=2,minimum_selected_recipients=1,minimum_accepted_packets=1,
    maximum_empty_downlink_actions=0,maximum_restore_logit_error=1e-6)


def action_class(i):
    return ['charge','downlink','desat','broadcast','continue'][i] if i<5 else 'image' if i<15 else 'transmit'


def packet_reconciles(packet, hold, packets):
    """Accept payload reduction only when a receipt during the hold explains it."""
    if not (hold.get('outcome') == 'hold_complete'
            and hold['sender'] == packet['sender'] and hold['receiver'] == packet['receiver']
            and abs(hold['end'] - packet['sent_at']) < 1e-6
            and hold['held_s'] + 1e-6 >= hold['required_hold_s']
            and packet['received_at'] + 1e-6 >= hold['end']
            and hold['payload_bytes'] >= packet['payload_bytes']):
        return False
    frozen, sent = set(hold['record_ids']), set(packet['record_ids'])
    acked = {record for q in packets if q['outcome'] == 'accepted'
             and {q['sender'], q['receiver']} == {packet['sender'], packet['receiver']}
             and hold['start'] - 1e-6 <= q['received_at'] <= packet['sent_at'] + 1e-6
             for record in q['record_ids']}
    return sent <= frozen and frozen - sent <= acked


def execute(cfg, output):
    import torch,numpy as np
    from ray.rllib.core.columns import Columns
    from examples.multiagent_imaging import train
    from examples.multiagent_imaging.checkpoints import load_policy,policy_callable,resume_checkpoint,optimizer_digest
    from examples.multiagent_imaging.evaluate import run_rollout
    from examples.multiagent_imaging.cluster.evidence.walker4_failure_audit_20260929.learner_probe import DiagnosticLearner
    torch.set_num_threads(1)
    os.environ['WALKER_AUDIT_LEARNER_OUTPUT']=str(output/'learner_batches')
    original=train.build_ppo_config
    train.build_ppo_config=lambda *a,**kw:original(*a,**kw).training(learner_class=DiagnosticLearner)
    resources=train.LauncherResources(num_env_runners=1,ray_cpus=8,torch_threads=1)
    train.train_run(cfg,iterations=1,train_batch_size=64,output=output,resources=resources)
    checkpoint=output/'checkpoint_0001'
    # Restores optimizer moments/counters and probes, without another update.
    algo=resume_checkpoint(checkpoint,cfg,resources=resources)
    manifest=json.loads((checkpoint/'manifest.json').read_text())
    resume=dict(optimizer_digest=optimizer_digest(algo),training_iteration=algo.training_iteration,
        expected_optimizer_digest=manifest['optimizer_sha256'],expected_training_iteration=manifest['training_iteration'])
    with (output/'optimizer_resume.json').open('x') as f:json.dump(resume,f,indent=2)
    algo.stop()
    import ray
    ray.shutdown()
    module,restore=load_policy(checkpoint,cfg)
    eval_cfg=replace(cfg,seed=7101)
    evaluations=[]
    for selection in ['stochastic','deterministic']:
        policy=policy_callable(module,deterministic=selection=='deterministic',seed=7101)
        decisions=[]
        def audited(obs):
            with torch.no_grad():
                logits=module.forward_inference({Columns.OBS:torch.tensor(obs,dtype=torch.float32).unsqueeze(0)})[Columns.ACTION_DIST_INPUTS][0]
                act=policy(obs)
                decisions.append(dict(action=act,action_class=action_class(act),storage=float(obs[0]),battery=float(obs[1]),
                    probabilities=logits.softmax(-1).tolist(),observation=np.asarray(obs).tolist(),valid=bool(logits[act]>-1e8)))
            return act
        result=run_rollout(eval_cfg,policy=audited)
        with (output/f'{selection}_evaluation.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
        with (output/f'{selection}_decisions.json').open('x') as f:json.dump(decisions,f,indent=2,allow_nan=False)
        histories=[h for hs in result['resource_history'].values() for h in hs]
        messages=result['message_diagnostics']
        checks=dict(full_horizon=abs(result['sim_time_s']-45000)<1e-6,
            qualified_capture=result['coverage']['qualified_exposure_count']>=1,
            full_ground_delivery=result['coverage']['qualified_ground_delivery_count']>=1,
            healthy_battery=min(h['battery_fraction'] for h in histories)>=.05,
            storage_margin=max(h['storage_fraction'] for h in histories)<.95,
            multiple_action_classes=len({d['action_class'] for d in decisions})>=2,
            selected_recipient=sum(messages['recipient_selection_counts'].values())>=1,
            accepted_packet=messages['packet_outcome_counts'].get('accepted',0)>=1,
            no_empty_downlink=not any(d['action']==1 and d['storage']<=cfg.empty_storage_mask_fraction for d in decisions),
            valid_actions=all(d['valid'] for d in decisions),
            decision_accounting=len(decisions)==sum(result['coordination']['policy_decisions'].values()))
        # Every accepted packet must follow the selected receiver's physical hold.
        checks['packet_reconciliation']=True
        for packet in messages['delivery_history']:
            if packet['outcome']!='accepted':continue
            checks['packet_reconciliation'] &= any(packet_reconciles(packet,h,messages['delivery_history'])
                for h in messages['transmission_history'])
        evaluations.append(dict(selection=selection,checks=checks,passed=all(checks.values()),
            initial_conditions_sha256=result['initial_conditions_sha256']))
    updates=json.loads((output/'updates.json').read_text())
    histories=[h for u in updates for e in u['episodes'] for h in e['resource_history']]
    training_checks=dict(full_horizon=all(abs(e['simulated_seconds']-45000)<1e-6 for u in updates for e in u['episodes']),
        healthy_battery=min(h['battery_fraction'] for h in histories)>=.05,
        storage_margin=max(h['storage_fraction'] for h in histories)<.95,
        finite_gradients=all(u['finite_gradients']==1 for u in updates),
        optimizer_resume=resume['optimizer_digest']==resume['expected_optimizer_digest'] and resume['training_iteration']==resume['expected_training_iteration'],restore=restore['max_logit_error']<=1e-6,
        paired_initial_conditions=evaluations[0]['initial_conditions_sha256']==evaluations[1]['initial_conditions_sha256'])
    result=dict(thresholds=THRESHOLDS,config=cfg.to_dict(),training_checks=training_checks,
        evaluations=evaluations,passed=all(training_checks.values()) and evaluations[0]['passed'],
        caveat='One seed and one update; gate pass allows further diagnosis, not a convergence or superiority claim. Resource minima sampled at simulator boundaries.')
    with (output/'gate.json').open('x') as f:json.dump(result,f,indent=2)
    print(json.dumps(result));return result['passed']


if __name__=='__main__':
    from examples.multiagent_imaging.config import MultiAgentImagingConfig
    p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
    cfg=replace(MultiAgentImagingConfig.from_json(a.config),seed=7100)
    assert cfg.episode_duration_s==45000 and cfg.n_sensors==4 and cfg.n_targets==100 and cfg.n_candidates==10 and cfg.retasking_mode=='conflict'
    assert not a.output.exists(),'Output must be fresh'
    if not a.execute:
        print(json.dumps(dict(prepared_only=True,num_env_runners=1,updates=1,config=cfg.to_dict(),thresholds=THRESHOLDS,output=str(a.output)),indent=2))
    else:
        if not execute(cfg,a.output):raise SystemExit('FAIL: review gate.json; do not scale to four workers')
