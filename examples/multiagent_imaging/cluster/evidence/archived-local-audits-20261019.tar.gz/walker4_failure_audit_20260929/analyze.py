"""Recompute only retained evidence. Missing quantities stay missing.

Run from the primary worktree with its verified Python, passing a fresh --output.
No simulator, training, network, or historical file writes occur here.
"""
import argparse
import csv
import json
import math
from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def read(p):
    return json.loads(p.read_text())


def write_csv(p, rows):
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with p.open("x", newline="") as f:
        w = csv.DictWriter(f, fields)
        w.writeheader()
        w.writerows(rows)


def distribution_rows(audit, **context):
    result = []
    for row in audit["rows"]:
        p = np.asarray(row["probabilities"], dtype=float)
        valid = np.asarray(row["valid"], dtype=bool)
        group_info = {}
        for name, sl in [("operational", slice(0, 5)), ("image", slice(5, 15)), ("peer", slice(15, 18))]:
            q = p[sl][valid[sl]]
            mass = q.sum()
            normalized = q / mass if mass else q
            h = -(normalized * np.log(np.maximum(normalized, 1e-30))).sum()
            group_info[name] = (mass, h / math.log(len(q)) if len(q) > 1 else None)
        for i, label in enumerate(audit["action_labels"]):
            group = "operational" if i < 5 else "image" if i < 15 else "peer"
            result.append(dict(**context, sensor_index=row["sensor_index"], action_index=i,
                action=label, valid=bool(valid[i]), valid_count=int(valid.sum()),
                logit=row["logits"][i], probability=p[i], argmax=int(p.argmax()) == i,
                categorical_draws=audit["sample_count"],
                categorical_count=round(row["empirical_frequencies"].get(label, 0) * audit["sample_count"]),
                normalized_entropy=row["normalized_entropy"], group=group,
                group_probability_mass=group_info[group][0],
                group_conditional_normalized_entropy=group_info[group][1]))
    return result


def analyze(root, out):
    v3 = root / "examples/multiagent_imaging/cluster/evidence/walker4_completion_v3_cluster_pilot"
    v4 = root / "results/multiagent_imaging/policy-recovery-v4-local-20260913"
    out.mkdir(parents=True, exist_ok=False)
    rows = []
    missing = ["entropy", "entropy_coefficient", "kl", "clipping_fraction", "explained_variance",
        "value_loss_unclipped", "optimizer_digest", "learner_samples", "observation_distribution",
        "advantage_distribution", "mask_frequency", "final_action_probabilities", "gradient_by_head"]
    with (v3 / "updates.csv").open() as f:
        for row in csv.DictReader(f):
            row = {k: (v == "True" if v in ["True", "False"] else float(v)) if v and k not in ["stage", "mode"] else v for k, v in row.items()}
            row.update(version="v3", selection="training_categorical", horizon_s=45000,
                source=str(v3 / "updates.csv"), **{k: None for k in missing})
            rows.append(row)
    probabilities, actions, resources, tasks, packet_checks, evaluations, observations = [], [], [], [], [], [], []
    for mode in ["conflict", "continuous"]:
        folder = v4 / (mode + "-1200-a")
        config = read(folder / "checkpoint_0001/manifest.json")["config"]
        for r in read(folder / "updates.json"):
            episodes, lm = r["episodes"], r["learner_metrics"]
            rh = [h for e in episodes for h in e["resource_history"]]
            reward = lambda name: float(np.mean([e["reward_decomposition"][name] for e in episodes]))
            row = dict(version="v4", stage="local_regression", mode=mode, selection="training_categorical", horizon_s=1200,
                iteration=r["iteration"], complete_episodes=len(episodes), actual_env_steps=r["actual_env_steps"],
                actual_agent_steps=r["actual_agent_steps"], actual_policy_decisions=r["actual_policy_decisions"],
                mean_constellation_reward=float(np.mean([e["constellation_reward"] for e in episodes])),
                mean_acquisition_reward=reward("acquisition_90_percent_component"),
                mean_ground_reward=reward("ground_delivery_10_percent_component"),
                mean_communication_adjustment=reward("communication_time_adjustment"),
                mean_other_penalties_or_adjustments=reward("other_operational_penalties_or_adjustments"),
                total_loss=r["losses"]["total_loss"], policy_loss=r["losses"]["policy_loss"], value_loss=r["losses"]["vf_loss"],
                value_loss_unclipped=lm["vf_loss_unclipped"], entropy=lm["entropy"], entropy_coefficient=lm["curr_entropy_coeff"],
                kl=lm["mean_kl_loss"], explained_variance=lm["vf_explained_var"],
                gradient_l2=r["gradient_l2"], parameter_change_l2=r["parameter_change"]["l2"],
                learner_samples=lm["num_module_steps_trained"],
                minimum_battery_fraction=min(h["battery_fraction"] for h in rh), maximum_storage_fraction=max(h["storage_fraction"] for h in rh),
                restored_logit_max_error=r["restore_validation"]["max_logit_error"],
                accepted_packets=sum(p["outcome"] == "accepted" for e in episodes for p in e["packets"]),
                optimizer_digest=read(folder / "checkpoint_0001/manifest.json")["optimizer_sha256"],
                source=str(folder / "updates.json"), **{k: None for k in ["clipping_fraction", "advantage_distribution", "mask_frequency", "gradient_by_head"]})
            rows.append(row)
            probabilities += distribution_rows(r["initial_observation_policy_distribution"], version="v4", mode=mode,
                iteration=r["iteration"], selection="frozen_reset_post_update", condition="reset", source=str(folder / "updates.json"))
            for j, e in enumerate(episodes):
                ctx = dict(version="v4", mode=mode, selection="training_categorical", iteration=r["iteration"], episode=j)
                for sensor, counts in e["action_selection_counts"].items():
                    actions += [dict(**ctx, sensor=sensor, action=a, count=n) for a, n in counts.items()]
                resources += [dict(**ctx, **h) for h in e["resource_history"]]
                extract_events(e["coordination"]["task_history"], e["transmissions"], e["packets"], ctx, tasks, packet_checks, config)
                a = np.asarray(e["probe_observations"])
                observations.append(dict(**ctx, scope="terminal_probes_only", count=a.shape[0],
                    finite=bool(np.isfinite(a).all()), minimum=float(a.min()), maximum=float(a.max()),
                    per_feature_min=a.min(0).tolist(), per_feature_max=a.max(0).tolist()))
        for cond, audit in read(folder / "initial_policy_gate.json").items():
            if isinstance(audit, dict) and "rows" in audit:
                probabilities += distribution_rows(audit, version="v4", mode=mode, iteration=0, selection="frozen_initial_probe",
                    condition=cond, source=str(folder / "initial_policy_gate.json"))
        for selection, e in read(folder / "evaluation_seed7000.json")["results"].items():
            ctx = dict(version="v4", mode=mode, selection=selection, iteration=1, seed=e["seed"])
            for sensor, counts in e["action_counts"].items():
                actions += [dict(**ctx, sensor=sensor, action=a, count=n) for a, n in counts.items()]
            rh = [dict(sensor=s, **h) for s, histories in e["resource_history"].items() for h in histories]
            resources += [dict(**ctx, **h) for h in rh]
            md = e["message_diagnostics"]
            extract_events(e["coordination"]["task_history"], md["transmission_history"], md["delivery_history"], ctx, tasks, packet_checks, config)
            evaluations.append(dict(**ctx, horizon_s=e["sim_time_s"], capture_coverage=e["coverage"]["capture_coverage_fraction"],
                ground_coverage=e["coverage"]["ground_delivery_coverage_fraction"], reward=e["reward_decomposition"]["total_constellation_reward"],
                minimum_battery=min(h["battery_fraction"] for h in rh), maximum_storage=max(h["storage_fraction"] for h in rh),
                accepted_packets=sum(p["outcome"] == "accepted" for p in md["delivery_history"]),
                source=str(folder / "evaluation_seed7000.json")))
    with (v3 / "held_out_metrics.csv").open() as f:
        for e in csv.DictReader(f):
            if e["controller"] != "policy":
                continue
            evaluations.append(dict(version="v3", mode=e["mode"], selection="deterministic", iteration=8,
                seed=int(e["seed"]), horizon_s=45000, capture_coverage=float(e["first_capture_coverage"]),
                ground_coverage=float(e["ground_delivery_coverage"]), reward=float(e["total_reward"]),
                minimum_battery=float(e["minimum_battery_fraction"]), maximum_storage=float(e["maximum_storage_fraction"]),
                accepted_packets=int(e["accepted_transport_packets"]), downlink_actions=int(e["downlink_action_selections"]),
                other_actions=int(e["other_action_selections"]), initial_conditions_sha256=e["initial_conditions_sha256"], source=str(v3 / "held_out_metrics.csv")))
    write_csv(out / "updates_diagnostic.csv", rows)
    for name, data in [("action_distributions", probabilities), ("actions", actions), ("resources", resources),
            ("task_durations", tasks), ("packet_reconciliation", packet_checks), ("evaluation_diagnostic", evaluations)]:
        write_csv(out / (name + ".csv"), data)
    (out / "terminal_observation_ranges.json").write_text(json.dumps(observations, indent=2, allow_nan=False) + "\n")
    availability = []
    for version in ["v3", "v4"]:
        for k in missing:
            status = "missing_raw_v3" if version == "v3" else "not_retained"
            if version == "v4" and k in ["entropy", "entropy_coefficient", "kl", "explained_variance", "value_loss_unclipped", "optimizer_digest", "learner_samples"]:
                status = "retained_per_update"
            if version == "v4" and k in ["observation_distribution", "final_action_probabilities"]:
                status = "frozen_or_terminal_probes_only"
            availability.append(dict(version=version, metric=k, availability=status))
    write_csv(out / "availability.csv", availability)
    plot_updates(rows, out)
    plot_resources(resources, tasks, out)
    plot_distribution(probabilities, out)
    print(json.dumps(dict(updates=len(rows), evaluation_rows=len(evaluations), packet_checks=len(packet_checks),
        packet_checks_passed=all(p["passed"] for p in packet_checks), output=str(out))))


def extract_events(history, transmissions, packets, ctx, tasks, checks, config):
    gamma = config["discount_per_s"]
    trace = math.exp(math.log(0.5) / config["gae_trace_half_life_s"])
    for t in history:
        dt = t["end"] - t["start"]
        assert dt >= -1e-8
        task = {("task_mode" if k == "mode" else k): v for k, v in t.items()}
        tasks.append(dict(**ctx, **task, duration_s=dt, reward_endpoint_discount=gamma**dt,
            gae_trace_weight=(gamma * trace)**dt))
    for p in packets:
        if p["outcome"] != "accepted":
            continue
        matches = [t for t in transmissions if t.get("outcome") == "hold_complete" and
            t["sender"] == p["sender"] and t["receiver"] == p["receiver"] and abs(t["end"] - p["sent_at"]) < 1e-6]
        good = len(matches) == 1 and p["received_at"] >= p["sent_at"]
        if good:
            t = matches[0]
            good = t["held_s"] >= t["required_hold_s"] - 1e-8 and t["required_hold_s"] >= 10 and t["payload_bytes"] == p["payload_bytes"]
        checks.append(dict(**ctx, sender=p["sender"], receiver=p["receiver"], sent_at=p["sent_at"],
            received_at=p["received_at"], records=p["records"], passed=bool(good)))


def style(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#dddddd", lw=0.5)


def plot_updates(rows, out):
    for mode in ["conflict", "continuous"]:
        fig, axes = plt.subplots(2, 3, figsize=(12, 7), layout="constrained")
        fig.suptitle(f"v3 {mode}: sampled training diagnostics\n45,000 s complete episodes; gate and fresh pilot are separate policies", fontsize=13)
        for ax, (field, title) in zip(axes.flat, [("mean_constellation_reward", "Episode return"), ("value_loss", "Clipped value loss"),
            ("policy_loss", "Policy loss"), ("gradient_l2", "Last reported gradient L2"),
            ("actual_policy_decisions", "Sampler decisions per update"), ("minimum_battery_fraction", "Minimum battery fraction")]):
            for stage, color, marker in [("one_worker_gate", "#d59a23", "s"), ("four_worker_pilot", "#2774ae", "o")]:
                rr = [r for r in rows if r["version"] == "v3" and r["mode"] == mode and r["stage"] == stage]
                x, y = [r["iteration"] for r in rr], [r[field] for r in rr]
                if len(rr) > 2:
                    ax.plot(x, y, color=color, marker=marker, lw=1.5, label=stage.replace("_", " "))
                else:
                    ax.scatter(x, y, color=color, marker=marker, label=stage.replace("_", " "))
            ax.set(title=title, xlabel="PPO update")
            style(ax)
        axes[0, 0].legend(fontsize=8)
        fig.savefig(out / f"v3_{mode}_updates.png", dpi=170)
        plt.close(fig)


def plot_resources(rows, tasks, out):
    for selection in ["deterministic", "stochastic"]:
        fig, axes = plt.subplots(2, 2, figsize=(10, 6), layout="constrained")
        fig.suptitle(f"v4 restored {selection}: resource histories\nSeed 7000, 1,200 s regression; no mission performance conclusion", fontsize=13)
        for i, mode in enumerate(["conflict", "continuous"]):
            for j, field in enumerate(["battery_fraction", "storage_fraction"]):
                ax = axes[i, j]
                for sensor in [f"sensor_{n}" for n in range(4)]:
                    rr = [r for r in rows if r["selection"] == selection and r["mode"] == mode and r["sensor"] == sensor]
                    ax.plot([r["time_s"] for r in rr], [r[field] for r in rr], lw=1.2,
                        color=["#155e93", "#2774ae", "#669fc2", "#8bb8d5"][int(sensor[-1])],
                        linestyle=["-", "--", ":", "-."][int(sensor[-1])], label=sensor)
                ax.set(title=f"{mode}: {field.replace('_', ' ')}", xlabel="Physical seconds")
                style(ax)
        axes[0, 0].legend(fontsize=8)
        fig.savefig(out / f"v4_{selection}_resources.png", dpi=170)
        plt.close(fig)


def plot_distribution(rows, out):
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), layout="constrained")
    fig.suptitle("v4 frozen reset action probabilities before and after one PPO update\n4 sensors averaged; categorical draws are probes, not rollout performance", fontsize=12)
    for ax, mode in zip(axes, ["conflict", "continuous"]):
        for it, color, marker in [(0, "#777777", "o"), (1, "#2774ae", "s")]:
            rr = [r for r in rows if r["mode"] == mode and r["iteration"] == it and r["condition"] in ["reset", "empty"]]
            ys = [np.mean([r["probability"] for r in rr if r["action_index"] == a]) for a in range(18)]
            ax.plot(range(18), ys, color=color, marker=marker, lw=1.2, label=f"update {it}")
        ax.set(title=mode, xlabel="Action index (image 5–14; peer 15–17)", ylabel="Probability", ylim=(-0.005, 0.11))
        style(ax)
        ax.legend(fontsize=8)
    fig.savefig(out / "v4_reset_probabilities.png", dpi=170)
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    analyze(args.root.resolve(), args.output.resolve())
