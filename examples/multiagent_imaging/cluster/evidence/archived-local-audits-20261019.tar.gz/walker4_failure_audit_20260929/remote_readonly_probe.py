"""Run on retained cluster artifacts; outputs JSON lines; no simulator or writes.

Compatible Python 3.11 / torch 2.4.1. Use weights_only for policy tensor payloads.
This reproduces the manual Termius transcription with full per-action precision.
"""
import argparse,collections,hashlib,json
from pathlib import Path
import torch

p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args()
torch.set_num_threads(1)
for mode in ['conflict','continuous']:
    folders=[*sorted((a.root/'one-worker'/mode).glob('*/checkpoint_*')),
        *sorted((a.root/'four-worker'/mode/'train').glob('checkpoint_*'))]
    for folder in folders:
        metadata=json.loads((folder/'manifest.json').read_text())
        digest=hashlib.sha256((folder/'policy.pt').read_bytes()).hexdigest()
        assert digest==metadata['policy_sha256']
        d=torch.load(folder/'policy.pt',map_location='cpu',weights_only=True)
        logits=d['logits'];prob=logits.softmax(-1);valid=logits>-1e8
        g=torch.Generator().manual_seed(2701)
        counts=torch.stack([torch.bincount(torch.multinomial(q,4096,True,generator=g),minlength=18) for q in prob])
        h=-(prob*prob.clamp_min(1e-30).log()).sum(-1)/valid.sum(-1).float().log()
        groups={}
        for label,start,end in [('operational',0,5),('image',5,15),('peer',15,18)]:
            q=prob[:,start:end];mass=q.sum(-1);conditional=q/mass[:,None].clamp_min(1e-30)
            n=valid[:,start:end].sum(-1);entropy=-(conditional*conditional.clamp_min(1e-30).log()).sum(-1)
            groups[label]=dict(mass=mass.tolist(),normalized_entropy=[None if ni<=1 else float(e/ni.float().log()) for ni,e in zip(n,entropy)])
        print(json.dumps(dict(mode=mode,folder=str(folder),policy_sha256=digest,schema=metadata['schema']['version'],
            training_iteration=metadata['training_iteration'],optimizer_digest=metadata['optimizer_sha256'],
            observations=d['observations'].tolist(),logits=logits.tolist(),probabilities=prob.tolist(),
            valid=valid.tolist(),normalized_entropy=h.tolist(),categorical_counts=counts.tolist(),
            argmax_counts=dict(collections.Counter(logits.argmax(-1).tolist())),groups=groups)),flush=True)
