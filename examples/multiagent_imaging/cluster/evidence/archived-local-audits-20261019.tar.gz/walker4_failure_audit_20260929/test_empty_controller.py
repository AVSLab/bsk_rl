"""Real-Basilisk controller rejection test, also runnable against archived v3."""
from examples.multiagent_imaging.config import MultiAgentImagingConfig
from examples.multiagent_imaging.environment import build_environment


def test_empty_downlink_rejected_before_task_start():
    cfg=MultiAgentImagingConfig(n_sensors=4,n_targets=100,n_candidates=10,
        episode_duration_s=10,max_step_duration_s=10,communication_mode='directed',information_case='completion')
    env=build_environment(cfg)
    try:
        obs,_=env.reset(seed=2701)
        assert all(obs[s.name].shape==(232,) and obs[s.name][0]==0 for s in env.sensing_satellites)
        try:
            env.step({s.name:1 for s in env.sensing_satellites})
        except ValueError as e:
            assert 'downlink' in str(e).lower()
            assert env.simulator.sim_time==0
            assert all(s.completion_task is None for s in env.sensing_satellites)
        else:
            raise AssertionError('Empty-storage downlink executed instead of being rejected')
    finally:
        env.close()


if __name__=='__main__':
    test_empty_downlink_rejected_before_task_start();print('PASS: controller rejects empty downlink before propagation')
