"""Reconcile retained v3 event histories without simulation or file writes."""
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args()
for mode in ['conflict','continuous']:
    for r in json.loads((a.root/'four-worker'/mode/'train/updates.json').read_text()):
        accepted=exact=reconciled=0;durations=[];reductions=[]
        for e in r['episodes']:
            durations.extend(t['end']-t['start'] for t in e['coordination']['task_history'])
            for packet in e['packets']:
                if packet['outcome']!='accepted':continue
                accepted+=1
                holds=[h for h in e['transmissions'] if h.get('outcome')=='hold_complete'
                    and h['sender']==packet['sender'] and h['receiver']==packet['receiver']
                    and abs(h['end']-packet['sent_at'])<1e-6
                    and h['held_s']+1e-6>=h['required_hold_s'] and packet['received_at']+1e-6>=h['end']]
                exact+=int(any(h['record_ids']==packet['record_ids'] for h in holds))
                good=False
                for h in holds:
                    sent=set(packet['record_ids']);frozen=set(h['record_ids'])
                    removed=frozen-sent
                    acked=set(record for q in e['packets'] if q['outcome']=='accepted'
                        and {q['sender'],q['receiver']}=={packet['sender'],packet['receiver']}
                        and h['start']-1e-6<=q['received_at']<=packet['sent_at']+1e-6
                        for record in q['record_ids'])
                    if sent<=frozen and removed<=acked:
                        good=True
                        if removed:reductions.append(dict(sent_at=packet['sent_at'],removed=len(removed),explained=len(removed&acked)))
                reconciled+=int(good)
        print(json.dumps(dict(mode=mode,iteration=r['iteration'],accepted_packets=accepted,
            exact_payload_matches=exact,reconciled_packets=reconciled,reductions=reductions,
            closed_tasks=len(durations),mean_duration_s=sum(durations)/len(durations),maximum_duration_s=max(durations))),flush=True)
