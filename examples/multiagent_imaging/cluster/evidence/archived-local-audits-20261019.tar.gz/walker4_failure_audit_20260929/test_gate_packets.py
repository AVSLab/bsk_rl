"""Screen the prepared gate's ACK filtering against transport/timing failures."""
from copy import deepcopy
from one_worker_gate import packet_reconciles


def test_ack_filter_and_physical_hold_contract():
    hold=dict(outcome='hold_complete',sender='sensor_0',receiver='sensor_1',
              start=10,end=20,held_s=10,required_hold_s=10,
              record_ids=['a','b'],payload_bytes=200)
    packet=dict(outcome='accepted',sender='sensor_0',receiver='sensor_1',
                sent_at=20,received_at=20,record_ids=['a','b'],payload_bytes=200)
    assert packet_reconciles(packet,hold,[packet])
    filtered=deepcopy(packet);filtered.update(record_ids=['a'],payload_bytes=100)
    assert not packet_reconciles(filtered,hold,[filtered])
    ack=dict(outcome='accepted',sender='sensor_1',receiver='sensor_0',
             sent_at=15,received_at=15,record_ids=['b'],payload_bytes=100)
    assert packet_reconciles(filtered,hold,[filtered,ack])
    for mutation in [dict(receiver='sensor_2'),dict(received_at=21),dict(received_at=9)]:
        wrong={**ack,**mutation}
        assert not packet_reconciles(filtered,hold,[filtered,wrong])
    for mutation in [dict(held_s=9),dict(end=19),dict(payload_bytes=99)]:
        assert not packet_reconciles(filtered,{**hold,**mutation},[filtered,ack])
    extra={**packet,'record_ids':['a','b','c']}
    assert not packet_reconciles(extra,hold,[extra])


if __name__ == '__main__':
    test_ack_filter_and_physical_hold_contract()
    print('PASS: exact payload and ACK-filtered subset; reject unexplained loss, wrong link/timing, short hold and extra records')
