"""Matched deterministic/stochastic short restored rollout with decision tensors."""
import argparse
import json
from dataclasses import replace
from pathlib import Path

import numpy as np
import torch
from ray.rllib.core.columns import Columns
from examples.multiagent_imaging.config import MultiAgentImagingConfig
from examples.multiagent_imaging.checkpoints import load_policy, policy_callable
from examples.multiagent_imaging.evaluate import run_rollout


def run(checkpoint, output, seed):
    output.mkdir(parents=True, exist_ok=False)
    cfg = MultiAgentImagingConfig(**json.loads((checkpoint/'manifest.json').read_text())['config'])
    assert cfg.episode_duration_s <= 1200
    module, restore = load_policy(checkpoint, cfg)
    torch.set_num_threads(1)
    summaries = []
    for selection in ['deterministic', 'stochastic']:
        rows, obs = [], []
        policy = policy_callable(module, deterministic=selection=='deterministic', seed=seed)

        def audited(observation):
            with torch.no_grad():
                batch = {Columns.OBS: torch.tensor(observation, dtype=torch.float32).unsqueeze(0)}
                logits = module.forward_inference(batch)[Columns.ACTION_DIST_INPUTS][0]
                p = torch.softmax(logits, -1)
                valid = logits > -1e8
                action = policy(observation)
                assert valid[action]
                rows.append(dict(action=action, argmax=int(logits.argmax()),
                    logits=logits.tolist(), probabilities=p.tolist(), valid=valid.tolist(),
                    battery_fraction=float(observation[1]), storage_fraction=float(observation[0]),
                    continue_valid=float(observation[25]), value=float(module.vf(batch).reshape(-1)[0])))
                obs.append(observation)
                return action

        result = run_rollout(replace(cfg, seed=seed), policy=audited)
        assert result['sim_time_s'] == cfg.episode_duration_s
        assert len(rows) == sum(result['coordination']['policy_decisions'].values())
        assert not any(r['action']==1 and r['storage_fraction']<=cfg.empty_storage_mask_fraction for r in rows)
        for name, data in [('rollout', result), ('decisions', rows)]:
            with (output/f'{selection}_{name}.json').open('x') as f:
                json.dump(data, f, indent=2, allow_nan=False)
        np.save(output/f'{selection}_observations.npy', np.asarray(obs,dtype=np.float32))
        summaries.append(dict(selection=selection, seed=seed, restore=restore,
            initial_conditions_sha256=result['initial_conditions_sha256'], decisions=len(rows),
            coverage=result['coverage'], reward=result['reward_decomposition'],
            accepted_packets=sum(p['outcome']=='accepted' for p in result['message_diagnostics']['delivery_history']),
            action_counts={str(a):sum(r['action']==a for r in rows) for a in range(18)}))
    assert summaries[0]['initial_conditions_sha256']==summaries[1]['initial_conditions_sha256']
    with (output/'summary.json').open('x') as f:
        json.dump(summaries,f,indent=2,allow_nan=False)
    print(json.dumps([dict(selection=s['selection'],decisions=s['decisions'],capture=s['coverage']['capture_coverage_fraction'],
        ground=s['coverage']['ground_delivery_coverage_fraction'],accepted_packets=s['accepted_packets']) for s in summaries]))


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--checkpoint',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seed',type=int,default=7001)
    a=p.parse_args()
    run(a.checkpoint,a.output,a.seed)
