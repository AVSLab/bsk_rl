# Reproduce without touching historical results

Use the primary worktree and its verified interpreter. Choose **fresh** result paths; every reproducer refuses existing outputs. Simulator results here require the current local Basilisk build and are regression evidence. Exact historical full-mission reproduction requires the retained cluster source/native runtime instead.

```bash
cd /Users/dahu1128/Repositories/bsk_rl-multi-agent-space-imaging-2026
audit=examples/multiagent_imaging/cluster/evidence/walker4_failure_audit_20260929
audit_python=/Users/dahu1128/Repositories/bsk_rl/.venv/bin/python
```

Read-only analysis, choosing fresh output directories:

```bash
PYTHONPATH=src:. "$audit_python" "$audit/analyze.py" --output "$audit/retained_analysis_replay"
PYTHONPATH=src:. "$audit_python" "$audit/finalize.py" --output "$audit/analysis_replay"
"$audit_python" "$audit/complete_diagnostics.py" --output "$audit/analysis_replay" --metadata-output "$audit/metadata_replay"
```

`finalize.py` uses the retained successful intermediate analysis and labeled cluster transcriptions. It requires no new simulation/training. For fresh full-precision remote measurements, run `remote_readonly_probe.py` and `remote_events_probe.py` where the original cluster tree is available, passing:

```text
--root /projects/dahu1128/bsk_rl-multi-agent-space-imaging-2026/results/multiagent_imaging/walker4-completion-v3-20260913
```

Those programs print JSON lines and do not modify cluster artifacts or start environments. The checkpoint program verifies hashes, emits original tensor observations/logits/probabilities, applies seed 2701 and draws 4096 samples per row, and emits overall/group entropy. Event reconciliation permits only payload subsets explained by receipts/ACK updates during the physical hold.

Expected-failure reproducer against exact v3, followed by the isolated correctness correction and current v4:

```bash
PYTHONPATH="$audit/v3_source/src:$audit/v3_source:." "$audit_python" "$audit/test_empty_downlink.py"
PYTHONPATH="$audit/v3_source/src:$audit/v3_source:." "$audit_python" "$audit/test_empty_controller.py"
PYTHONPATH="$audit/empty_storage_fix_source/src:$audit/empty_storage_fix_source:." "$audit_python" "$audit/test_empty_downlink.py"
PYTHONPATH="$audit/empty_storage_fix_source/src:$audit/empty_storage_fix_source:." "$audit_python" "$audit/test_empty_controller.py"
PYTHONPATH=src:. "$audit_python" "$audit/test_empty_downlink.py"
PYTHONPATH=src:. "$audit_python" "$audit/test_empty_controller.py"
```

First two commands must raise AssertionError. Remaining commands must pass. `minimal_empty_storage_fix.patch` is against the archived v3 executable source; applying it creates a new schema, so old weights must not be presented as a compatible restored corrected checkpoint. Rebuild its isolated source/patch with fresh paths:

```bash
"$audit_python" "$audit/make_minimal_patch.py" --source-output "$audit/empty_storage_fix_replay" --patch-output "$audit/minimal_fix_replay.patch"
```

Do not apply this patch to the dirty primary v4 worktree.

Focused connector/architecture tests (actual successful command; 16 pass):

```bash
PYTHONPATH=src:. "$audit_python" -m pytest -q \
  tests/unittest/multiagent/test_completion_policy_mask.py \
  tests/unittest/multiagent/test_completion_set_attention.py \
  tests/unittest/multiagent/test_async_discounting.py \
  tests/unittest/multiagent/test_directed_hold.py \
  tests/unittest/multiagent/test_shared_policy.py
```

Frozen physical reset/path/permutation probes (4096 draws per sensor/state):

```bash
PYTHONPATH="$audit/v3_source/src:$audit/v3_source:." "$audit_python" "$audit/probe.py" \
  --config "$audit/v3_conflict_config.json" --output "$audit/v3_initial_replay.json" --seed 0
PYTHONPATH=src:. "$audit_python" "$audit/probe.py" \
  --config examples/multiagent_imaging/configs/walker4_mixed_recovery_1200_conflict.json \
  --checkpoint results/multiagent_imaging/policy-recovery-v4-local-20260913/conflict-1200-a/checkpoint_0001 \
  --output "$audit/v4_reset_replay.json" --seed 0
PYTHONPATH=src:. "$audit_python" "$audit/physical_probe.py" \
  --checkpoint results/multiagent_imaging/policy-recovery-v4-local-20260913/conflict-1200-a/checkpoint_0001 \
  --output "$audit/physical_replay.json"
```

Matched short rollouts, no cluster allocation:

```bash
PYTHONPATH=src:. "$audit_python" "$audit/rollout_probe.py" \
  --checkpoint results/multiagent_imaging/policy-recovery-v4-local-20260913/conflict-1200-a/checkpoint_0001 \
  --output "$audit/rollout_replay_seed7001" --seed 7001
```

The one local PPO update was run with zero remote environment runners, batch minimum 64 and unchanged existing v4 hyperparameters. Its stable-import invocation was:

```bash
PYTHONPATH=src:. "$audit_python" -c 'from examples.multiagent_imaging.cluster.evidence.walker4_failure_audit_20260929.learner_probe import run; run("examples/multiagent_imaging/configs/walker4_mixed_recovery_1200_conflict.json", "examples/multiagent_imaging/cluster/evidence/walker4_failure_audit_20260929/local_update_replay")'
```

This would execute another local update; it is documented for reproduction, not automatically run again. Exact cross-platform simulation equality is not assumed. Retained arrays explain this audit's realized 86 distinct decisions, 96 presentations and 10 repeats. The instrumented loss is unchanged; additional autograd calls retain the graph and measure component gradients before normal backward/clipping.

Restore-only validation (no additional PPO update):

```bash
PYTHONPATH=src:. "$audit_python" "$audit/resume_probe.py" \
  --checkpoint "$audit/local_update_v2/checkpoint_0001" --output "$audit/resume_replay.json"
```

The mission gate defaults to a non-executing plan:

```bash
PYTHONPATH=src:. "$audit_python" "$audit/one_worker_gate.py" \
  --config examples/multiagent_imaging/configs/walker4_mixed_preflight_conflict.json \
  --output results/multiagent_imaging/walker4-failure-audit-gate-replay
bash -n "$audit/gate.slurm"
"$audit_python" "$audit/test_gate_packets.py"
```

The report contains the explicit `--execute` command and thresholds. Cluster submission or gate execution requires new explicit approval. No broader run is authorized by this evidence package.
