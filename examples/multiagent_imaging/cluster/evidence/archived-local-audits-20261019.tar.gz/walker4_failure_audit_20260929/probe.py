"""Frozen real reset, controlled resource features, path/permutation equivalence.

Use a schema-compatible source path in PYTHONPATH. No PPO or cluster launch.
Paired tensor mutations are explicitly distinguished from physical observations.
"""
import argparse
import json
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch
from ray.rllib.algorithms.ppo.ppo_catalog import PPOCatalog
from ray.rllib.core.columns import Columns
from ray.rllib.core.rl_module.rl_module import RLModuleSpec

from bsk_rl.utils.rllib.target_gnn_module import GNNModule
from examples.multiagent_imaging.config import MultiAgentImagingConfig
from examples.multiagent_imaging.environment import build_environment
from examples.multiagent_imaging.train import target_attention_config
from examples.multiagent_imaging.checkpoints import load_policy
from bsk_rl.obs.completion_observations import OBSERVATION_VERSION


def main(args):
    torch.set_num_threads(1)
    torch.manual_seed(args.seed)
    cfg = MultiAgentImagingConfig(**json.loads(args.config.read_text()))
    env = build_environment(cfg)
    try:
        obs, _ = env.reset(seed=cfg.seed)
        real = np.asarray([obs[f"sensor_{i}"] for i in range(4)], dtype=np.float32)
        assert real.shape == (4, 232) and all(s.action_space.n == 18 for s in env.sensing_satellites)
        assert np.isfinite(real).all()
        initial_ids = {s.name: [None if t is None else t.id for t in s.completion_candidates.targets] for s in env.sensing_satellites}
        obs, *_ = env.step({s.name: 5 for s in env.sensing_satellites})
        env.generate_obs_retasking_only = False
        obs = env._get_obs()
        active = np.asarray([obs[f"sensor_{i}"] for i in range(4)], dtype=np.float32)
        assert active.shape == (4, 232) and np.isfinite(active).all()
        physical_state = dict(time_s=env.simulator.sim_time,
            tasks={s.name: vars(s.completion_task) for s in env.sensing_satellites},
            battery=[s.dynamics.battery_charge_fraction for s in env.sensing_satellites],
            storage=[s.dynamics.storage_level_fraction for s in env.sensing_satellites],
            peer_ids={s.name: [None if p is None else p.name for p in s.completion_peers.peers] for s in env.sensing_satellites})
    finally:
        env.close()
    if args.checkpoint:
        module, restore = load_policy(args.checkpoint, cfg)
    else:
        module = RLModuleSpec(module_class=GNNModule, catalog_class=PPOCatalog,
            observation_space=gym.spaces.Box(-np.inf, np.inf, (232,), np.float32),
            action_space=gym.spaces.Discrete(18), model_config_dict=target_attention_config(cfg)).build()
        restore = None
    module.eval()
    filled, low, continuing = real.copy(), real.copy(), real.copy()
    filled[:, 0] = 0.1
    low[:, 1] = 0.04
    continuing[:, 1], continuing[:, 25] = 0.04, 1
    cases = {"real_reset": real, "real_after_imaging_boundary": active,
        "tensor_products_present": filled, "tensor_low_battery": low, "tensor_low_battery_active_continue": continuing}
    for peer in range(3):
        x = filled.copy()
        x[:, 196:].reshape(4, 3, 12)[:, :, -1] = 0
        x[:, 196:].reshape(4, 3, 12)[:, peer, -1] = 1
        cases[f"tensor_peer_{peer}_eligible"] = x
    rows, errors = [], []
    rng = torch.Generator().manual_seed(args.seed)
    for name, obs in cases.items():
        batch = {Columns.OBS: torch.tensor(obs)}
        with torch.no_grad():
            logits = module.forward_inference(batch)[Columns.ACTION_DIST_INPUTS]
            for path in [module.forward_exploration, module.forward_train]:
                other = path(batch)[Columns.ACTION_DIST_INPUTS]
                error = float((other - logits).abs().max())
                errors.append(dict(case=name, path=path.__name__, max_error=error))
                torch.testing.assert_close(logits, other, rtol=0, atol=0)
            p = torch.softmax(logits, -1)
            counts = torch.stack([torch.bincount(torch.multinomial(q, 4096, True, generator=rng), minlength=18) for q in p])
            valid = logits > -1e8
            assert not counts[~valid].any()
            for i in range(4):
                entropy = -(p[i] * p[i].clamp_min(1e-30).log()).sum()
                rows.append(dict(case=name, sensor=i, valid=valid[i].tolist(), valid_count=int(valid[i].sum()),
                    logits=logits[i].tolist(), probabilities=p[i].tolist(), argmax=int(logits[i].argmax()),
                    categorical_counts=counts[i].tolist(), sample_count=4096,
                    normalized_entropy=float(entropy / np.log(int(valid[i].sum()))) if valid[i].sum() > 1 else 1,
                    value=float(module.vf(batch).squeeze(-1)[i])))
    # Include valid peers so peer permutations exercise scores, rather than only masked sentinels.
    x = filled.copy()
    x[:, 196:].reshape(4, 3, 12)[:, :, -1] = 1
    xp = x.copy()
    tp, pp = [7, 4, 9, 1, 5, 3, 0, 8, 6, 2], [2, 0, 1]
    xp[:, 26:196] = x[:, 26:196].reshape(4, 10, 17)[:, tp].reshape(4, -1)
    xp[:, 196:] = x[:, 196:].reshape(4, 3, 12)[:, pp].reshape(4, -1)
    with torch.no_grad():
        a = module.forward_inference({Columns.OBS: torch.tensor(x)})[Columns.ACTION_DIST_INPUTS]
        b = module.forward_inference({Columns.OBS: torch.tensor(xp)})[Columns.ACTION_DIST_INPUTS]
        expected = a[:, [0, 1, 2, 3, 4, *[5+i for i in tp], *[15+i for i in pp]]]
        torch.testing.assert_close(b, expected, atol=1e-6, rtol=1e-5)
        perm_error = float((b - expected).abs().max())
    result = dict(schema_version=OBSERVATION_VERSION, seed=args.seed, config=cfg.to_dict(),
        module_source=__import__('bsk_rl.utils.rllib.target_gnn_module',fromlist=['']).__file__,
        checkpoint=str(args.checkpoint) if args.checkpoint else None, restore=restore,
        physical_state=physical_state, initial_target_ids=initial_ids, rows=rows,
        path_errors=errors, permutation_max_error=perm_error,
        caveat="Current local Basilisk runtime; controlled tensor states are not physical mission trajectories.")
    with args.output.open("x") as f:
        json.dump(result, f, indent=2, allow_nan=False)
    np.savez(args.output.with_suffix('.npz'), **cases)
    print(json.dumps(dict(schema_version=OBSERVATION_VERSION, checkpoint=result['checkpoint'],
        restore=restore, reset_argmax=[r['argmax'] for r in rows if r['case']=='real_reset'],
        reset_downlink_probability=[r['probabilities'][1] for r in rows if r['case']=='real_reset'],
        permutation_max_error=perm_error)))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--config', type=Path, required=True)
    p.add_argument('--checkpoint', type=Path)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--seed', type=int, default=1701)
    main(p.parse_args())
