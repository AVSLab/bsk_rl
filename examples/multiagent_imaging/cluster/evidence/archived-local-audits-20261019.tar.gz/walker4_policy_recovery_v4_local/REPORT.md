# Walker-4 completion-v4 local policy recovery

one-update 1200-second local regression; not mission performance evidence.

The prior completion-v3 cluster pilot used stochastic actor sampling, while its evaluation used deterministic argmax. Reproducing that initialization showed a high-entropy distribution with a small downlink logit lead; the old evidence did not retain final per-action probabilities. RLlib entropy regularization was also left at its zero default. That made the all-downlink evaluation invalid as evidence of a learned operational policy.

The v4 recovery calibrates all action heads, masks empty downlink and newly started powered tasks below a local battery reserve, leaves charge as a fallback, uses entropy coefficient 0.02, and records probabilities, masks, categorical samples, action counts, entropy, gradients, and parameter changes. Old v3 checkpoints fail the versioned schema.

## Real-Basilisk initialization gate

| Mode | Normalized entropy range | Max/min valid probability | Empty-storage valid set |
|---|---:|---:|---|
| conflict | 0.999995–0.999996 | 1.0147 | charge, desat, ten image slots |
| continuous | 0.999995–0.999996 | 1.0147 | charge, desat, ten image slots |

Each row used 4,096 empirical categorical draws. Downlink was absent only when local storage was empty and became valid in the paired product-present probe. All ten target slots were valid on the actual four-sensor, 100-target mixed-population reset.
The paired connected-peer probe also enabled all three directed receiver slots;
the minimum normalized entropy across empty, product-present, and connected-peer
conditions was 0.999994 and the maximum valid-probability ratio was 1.0147.  Exact
logits, probabilities, masks, and samples are retained in `initial_policy_gate.json`.

## One PPO update

| Mode | Complete episodes | Decisions | Policy / value / total loss | Entropy | Gradient L2 | Parameter delta L2 | Mean sampled reward |
|---|---:|---:|---:|---:|---:|---:|---:|
| conflict | 2 | 89 | -0.1298 / 5.7262 / 5.5445 | 2.6014 | 2.3334 | 0.0155 | 22.292 |
| continuous | 4 | 260 | -0.2870 / 4.4688 / 4.1290 | 2.6412 | 3.8743 | 0.0357 | 12.243 |

Both checkpoints restored with zero logit error and identical deterministic actions. Losses and gradients were finite, gradients and parameters changed, and the configured entropy coefficient was present in the learner metrics.

## Matched seed-7000 short evaluation

| Mode | Selection | Capture coverage | Ground coverage | Qualified exposures | Reward | Accepted packets | Minimum battery |
|---|---|---:|---:|---:|---:|---:|---:|
| conflict | deterministic | 29.0% | 0.0% | 45 | 25.744 | 0 | 0.8728 |
| conflict | stochastic | 25.0% | 0.0% | 25 | 21.327 | 2 | 0.8708 |
| continuous | deterministic | 18.0% | 0.0% | 21 | 14.462 | 0 | 0.8727 |
| continuous | stochastic | 9.0% | 0.0% | 10 | 8.739 | 1 | 0.8726 |

The deterministic policies used multiple image candidate identities instead of selecting empty downlink. Stochastic evaluation also selected charge/desaturation, valid downlink after products existed, and directed peer transmission; three completion packets were accepted across the two modes. A 1,200-second episode is too short to require a ground pass, so zero ground delivery here is an explicit remaining mission-scale gate, not a pass. No cluster recovery job or four-worker learning was launched for this evidence.
